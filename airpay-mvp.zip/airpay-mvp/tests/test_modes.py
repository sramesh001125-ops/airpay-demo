import pytest

from airpay.crypto import Signer
from airpay.service import Service, ServiceError
from airpay.sims import bank_sign
from airpay.pos.crew_device import CrewDevice
from tests.helpers import MOB, Clock, checks, hook, sync


def world(n=1):
    clk = Clock()
    svc = Service(clock=clk, lender_terms_confirmed=True, credit_mode="A_SB_OVERDRAFT")
    d = CrewDevice("AC1", "6E-201", clock=clk)
    for _ in range(n):
        d.sell(400, "meal", MOB)
    svc.register_device("AC1", d.public_key)
    sync(svc, d)
    return svc, clk


O = "6E-201-AC1-0001"


def paid(svc):
    svc.request_payment(O)
    hook(svc, O, "PAID")


def opened(svc, clk, ref="TOD-1", charge=15, ts=None, sig=None):
    ts = int(clk()) if ts is None else ts
    return svc.bank_tod_opened(O, ref, charge, ts, sig or bank_sign(O, "TOD_OPENED", ref, charge, ts))


def cleared(svc, clk, ref="TOD-1"):
    ts = int(clk())
    return svc.bank_tod_cleared(O, ref, ts, bank_sign(O, "TOD_CLEARED", ref, 0, ts))


def test_mode_a_refuses_airpay_credit_offer():
    svc, clk = world()
    svc.request_payment(O); hook(svc, O, "FAILED")
    with pytest.raises(ServiceError):
        svc.offer_credit(O)


def test_mode_a_overdraft_blocks_then_clears():
    svc, clk = world()
    paid(svc)
    opened(svc, clk)
    assert MOB in svc.blocked_mobiles()
    assert not checks(svc)
    cleared(svc, clk)
    assert MOB not in svc.blocked_mobiles()
    assert not checks(svc)


def test_mode_a_bad_signature_stale_and_replay():
    svc, clk = world()
    paid(svc)
    with pytest.raises(ServiceError): opened(svc, clk, sig="0" * 64)
    with pytest.raises(ServiceError): opened(svc, clk, ts=int(clk()) - 10_000, sig=bank_sign(O, "TOD_OPENED", "TOD-1", 15, int(clk()) - 10_000))
    opened(svc, clk)
    assert opened(svc, clk) == "TOD_OPEN"                      # idempotent replay
    with pytest.raises(ServiceError): opened(svc, clk, ref="TOD-2")   # second overdraft on same order


def test_mode_a_requires_bank_paid_order_and_sane_charge():
    svc, clk = world()
    with pytest.raises(ServiceError): opened(svc, clk)         # not paid yet
    paid(svc)
    with pytest.raises(ServiceError): opened(svc, clk, charge=5000, sig=bank_sign(O, "TOD_OPENED", "TOD-1", 5000, int(clk())))
    with pytest.raises(ServiceError): opened(svc, clk, charge=True)


def test_mode_a_overdue_and_npa_flagged_never_written_off():
    svc, clk = world()
    paid(svc); opened(svc, clk)
    clk.t += 8 * 86400
    assert "A14_TOD_OVERDUE" in checks(svc)
    clk.t += 90 * 86400
    assert "A14_TOD_NPA" in checks(svc)
    assert svc.orders[O].state.value == "PAID_VERIFIED"


def test_mode_b_rejects_bank_events_and_audit_flags_mode_violation():
    svc, clk = world()
    svc.credit_mode = "B_SEPARATE_LOAN"
    paid(svc)
    with pytest.raises(ServiceError): opened(svc, clk)


def test_clear_requires_matching_open_overdraft():
    svc, clk = world()
    paid(svc)
    with pytest.raises(ServiceError): cleared(svc, clk)
    opened(svc, clk)
    with pytest.raises(ServiceError): cleared(svc, clk, ref="WRONG")
