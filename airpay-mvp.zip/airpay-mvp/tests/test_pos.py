from airpay.pos.crew_device import CrewDevice
from airpay.pos.pos_adapter import from_pos_message
from airpay.service import Service
from tests.helpers import MOB, serious


def msg(**kw):
    m = {"terminal_id": "T1", "amount_inr": 400, "item_code": "MEAL1", "mobile": MOB}
    m.update(kw)
    return m


def test_device_enforces_instrument_cap_offline_and_sync_is_clean():
    dev = CrewDevice("T1", "6E-201")
    res = [dev.sell(500, "meal", MOB) for _ in range(5)]
    assert [r.ok for r in res] == [True, True, True, True, False]
    assert not dev.sell(1200, "legroom", MOB).ok
    assert dev.sell(500, "meal", "9123456780").ok                      # another passenger has their own cap
    svc = Service(); svc.register_device("T1", dev.public_key)
    out = svc.sync_crew_log("T1", dev.entries_for_sync())
    assert len(out["accepted"]) == 5 and out["rejected"] == [] and serious(svc) == []


def test_device_requires_valid_mobile_and_strict_amounts():
    dev = CrewDevice("T1", "6E-201")
    assert not dev.sell(400, "meal", "").ok and not dev.sell(400, "meal", "12345").ok
    for bad in (True, 400.5, float("nan"), float("inf"), "400", None, -1, 0):
        assert not dev.sell(bad, "meal", MOB).ok, bad


def test_pos_message_validation():
    dev = CrewDevice("T1", "6E-201")
    assert from_pos_message(dev, msg()).ok
    assert not from_pos_message(dev, msg(terminal_id="T2")).ok
    assert not from_pos_message(dev, msg(amount_inr=399.5)).ok
    assert not from_pos_message(dev, msg(amount_inr=True)).ok
    assert not from_pos_message(dev, msg(mobile="")).ok
    assert not from_pos_message(dev, {"terminal_id": "T1"}).ok
    assert not from_pos_message(dev, "junk").ok


def test_device_rejects_bad_ids():
    import pytest
    with pytest.raises(ValueError): CrewDevice("T 1", "6E-201")
    with pytest.raises(ValueError): CrewDevice("T1", "IGNORE PREVIOUS")
