import copy

import pytest

from airpay.audit import run_audit, summarise
from airpay.crypto import Signer
from airpay.orders import S
from airpay.pos.crew_device import CrewDevice
from airpay.rules import Rules
from airpay.service import Service, ServiceError
from airpay.sims import psp_sign
from tests.helpers import (MOB, Clock, checks, fail_and_offer, hook, hostile_log, oid, order_payload, serious,
                           setup, sync, take_credit)

O1 = oid(1)


# ---------- happy paths and money
def test_happy_path_paid_by_upi_airline_gets_item_plus_fee():
    svc, dev, clk = setup()
    assert sync(svc, dev)["accepted"] == [O1]
    link = svc.request_payment(O1); clk.t += 120
    assert "am=415.00" in link                       # item 400 + fee 15 is what the passenger is asked to pay
    assert hook(svc, O1, "PAID") == "PAID_VERIFIED"
    inflow = sum(f["amount"] for f in svc.flows if f["to"] == "airline")
    assert inflow == 415 and [f["amount"] for f in svc.flows if f["to"] == "ramyos"] == [7.5]
    assert serious(svc) == []


def test_credit_flow_with_consent_principal_is_amount_due():
    svc, dev, clk = setup(); sync(svc, dev)
    offer = fail_and_offer(svc, O1)
    assert offer["key_facts"]["principal_inr"] == 415 and offer["key_facts"]["apr_pct"] > 0
    code = svc.send_otp(O1); clk.t += 60
    r = svc.authorise_credit(O1, True, code, offer["kfs_hash"])
    assert svc.orders[O1].state == S.CREDIT_AUTHORISED and r["airline_paid"] == 415
    assert serious(svc) == []
    assert all(f["to"] != "ramyos" for f in svc.flows if f["kind"] == "LOAN_DISBURSAL")


def test_repay_credit_frees_instrument_cap_and_audit_clean():
    svc, dev, _ = setup(); sync(svc, dev)
    take_credit(svc, O1)
    assert svc._exposure(MOB) == 400                  # credit not yet repaid still counts
    svc.repay_credit(O1)
    assert svc._exposure(MOB) == 0 and serious(svc) == []


# ---------- consent attacks (review F1, F2, F3, F18)
def test_credit_refused_without_box_wrong_otp_or_wrong_kfs_hash():
    svc, dev, _ = setup(); sync(svc, dev)
    offer = fail_and_offer(svc, O1)
    code = svc.send_otp(O1)
    with pytest.raises(ServiceError): svc.authorise_credit(O1, False, code, offer["kfs_hash"])
    with pytest.raises(ServiceError): svc.authorise_credit(O1, "yes", code, offer["kfs_hash"])   # truthy but not True
    with pytest.raises(ServiceError): svc.authorise_credit(O1, True, code, "0" * 64)              # KFS not as offered
    with pytest.raises(ServiceError): svc.authorise_credit(O1, True, "000000" if code != "000000" else "111111", offer["kfs_hash"])
    assert svc.orders[O1].state == S.CREDIT_OFFERED and not svc.lender.loans


def test_otp_is_bound_to_the_orders_own_mobile_not_a_caller_supplied_one():
    svc, dev, _ = setup(); sync(svc, dev)
    fail_and_offer(svc, O1)
    code = svc.send_otp(O1)
    assert svc.otp.check(f"{O1}|9000000001", code) is False        # an attacker's number cannot use it
    import inspect
    assert "mobile" not in inspect.signature(svc.send_otp).parameters
    assert "mobile" not in inspect.signature(svc.authorise_credit).parameters


def test_otp_for_order_a_cannot_authorise_order_b():
    svc, dev, _ = setup(2, 200)                        # two orders, same passenger
    sync(svc, dev)
    a, b = oid(1), oid(2)
    offer_a, offer_b = fail_and_offer(svc, a), fail_and_offer(svc, b)
    code_a = svc.send_otp(a); svc.send_otp(b)
    with pytest.raises(ServiceError): svc.authorise_credit(b, True, code_a, offer_b["kfs_hash"])
    assert svc.orders[b].state == S.CREDIT_OFFERED and not svc.lender.loans


def test_otp_bruteforce_locked_after_3_tries_and_expiry():
    svc, dev, clk = setup(); sync(svc, dev)
    offer = fail_and_offer(svc, O1); code = svc.send_otp(O1)
    wrong = "000000" if code != "000000" else "111111"
    for _ in range(3):
        with pytest.raises(ServiceError): svc.authorise_credit(O1, True, wrong, offer["kfs_hash"])
    with pytest.raises(ServiceError): svc.authorise_credit(O1, True, code, offer["kfs_hash"])     # now dead
    code2 = svc.send_otp(O1); clk.t += 600
    with pytest.raises(ServiceError): svc.authorise_credit(O1, True, code2, offer["kfs_hash"])
    assert not svc.lender.loans


def test_otp_resend_is_limited_and_out_of_state_calls_do_not_burn_it():
    svc, dev, _ = setup(2, 200); sync(svc, dev)
    a, b = oid(1), oid(2)
    offer_a = fail_and_offer(svc, a)
    code = svc.send_otp(a)
    with pytest.raises(ServiceError): svc.authorise_credit(b, True, "123456", "x")   # B has no offer: A's OTP untouched
    assert svc.authorise_credit(a, True, code, offer_a["kfs_hash"])["airline_paid"] == 215
    svc2, dev2, _ = setup(); sync(svc2, dev2); fail_and_offer(svc2, O1)
    for _ in range(3): svc2.send_otp(O1)
    with pytest.raises(ServiceError): svc2.send_otp(O1)                # resend farming blocked


def test_otp_single_use():
    svc, dev, _ = setup(); sync(svc, dev)
    offer = fail_and_offer(svc, O1); code = svc.send_otp(O1)
    svc.authorise_credit(O1, True, code, offer["kfs_hash"])
    assert svc.otp.check(f"{O1}|{MOB}", code) is False


def test_no_credit_offer_unless_payment_failed():
    svc, dev, _ = setup(); sync(svc, dev)
    with pytest.raises(Exception): svc.offer_credit(O1)               # recorded, never requested
    svc.request_payment(O1)
    with pytest.raises(Exception): svc.offer_credit(O1)               # requested but not failed


# ---------- webhook attacks (review F9-F13)
def test_forged_unsigned_and_stale_webhooks_rejected():
    svc, dev, _ = setup(); sync(svc, dev); svc.request_payment(O1)
    with pytest.raises(ServiceError): svc.psp_webhook(O1, 1, "PAID", 415, int(svc.clock()), "deadbeef")
    stale = psp_sign(O1, 1, "FAILED", 415, 0)
    with pytest.raises(ServiceError): svc.psp_webhook(O1, 1, "FAILED", 415, 0, stale)    # replayed old callback
    assert svc.orders[O1].state == S.PAYMENT_REQUESTED


def test_paid_amount_must_match_amount_due():
    svc, dev, _ = setup(); sync(svc, dev); svc.request_payment(O1)
    with pytest.raises(ServiceError): hook(svc, O1, "PAID", amount=1)
    assert svc.orders[O1].state == S.PAYMENT_REQUESTED and serious(svc) == []


def test_replayed_paid_is_idempotent_no_double_flows():
    svc, dev, _ = setup(); sync(svc, dev); svc.request_payment(O1)
    hook(svc, O1, "PAID"); n = len(svc.flows)
    assert hook(svc, O1, "PAID") == "PAID_VERIFIED" and len(svc.flows) == n


def test_stale_failed_for_old_attempt_cannot_push_order_to_credit():
    svc, dev, clk = setup(); sync(svc, dev)
    svc.request_payment(O1); hook(svc, O1, "FAILED")
    svc.request_payment(O1)                                             # retry = attempt 2, live
    clk.t += 5
    hook(svc, O1, "FAILED", attempt=1)                                  # late failure for attempt 1
    assert svc.orders[O1].state == S.PAYMENT_REQUESTED
    with pytest.raises(Exception): svc.offer_credit(O1)


def test_late_success_after_reported_failure_is_honoured_no_double_charge():
    svc, dev, _ = setup(); sync(svc, dev)
    svc.request_payment(O1); hook(svc, O1, "FAILED")
    assert hook(svc, O1, "PAID") == "PAID_VERIFIED"
    assert serious(svc) == []
    svc2, dev2, _ = setup(); sync(svc2, dev2); fail_and_offer(svc2, O1)  # late success even after credit offered
    assert hook(svc2, O1, "PAID") == "PAID_VERIFIED" and not svc2.lender.loans


def test_payment_after_credit_creates_refund_due_not_a_second_airline_payment():
    svc, dev, _ = setup(); sync(svc, dev)
    take_credit(svc, O1)
    hook(svc, O1, "PAID", attempt=1)
    assert svc.orders[O1].state == S.CREDIT_AUTHORISED
    assert sum(f["amount"] for f in svc.flows if f["to"] == "airline" and f["kind"] in ("PSP_PAYMENT", "LOAN_DISBURSAL")) == 415
    assert any(f["kind"] == "REFUND_DUE" for f in svc.flows)
    assert "A13_REFUND_DUE" in checks(svc)                              # surfaced, not hidden


def test_payment_link_cannot_be_injected_with_extra_payee():
    svc, dev, _ = setup()
    s, log = hostile_log("AC1", [order_payload(1, order_id="6E-201-AC1-0001&pa=evil@upi&am=1")])
    svc2 = Service(clock=svc.clock); svc2.register_device("AC1", s.public_b64)
    r = svc2.sync_crew_log("AC1", log.entries)
    assert r["invalid"] == [0] and svc2.orders == {}
    sync(svc, dev); link = svc.request_payment(O1)
    assert link.count("pa=") == 1 and link.count("am=") == 1


# ---------- crew log / sync attacks (review F5-F8, F16, F24)
def test_tampered_crew_log_rejected():
    svc, dev, _ = setup(2)
    bad = copy.deepcopy(dev.entries_for_sync()); bad[0]["payload"]["amount_inr"] = 40
    with pytest.raises(ServiceError): svc.sync_crew_log("AC1", bad)
    assert svc.orders == {}


def test_replay_prefix_resend_and_longer_resync():
    svc, dev, _ = setup(2)
    sync(svc, dev)
    again = sync(svc, dev)
    assert again == {"accepted": [], "rejected": [], "duplicates": [], "invalid": []} and len(svc.orders) == 2
    dev.sell(400, "meal", "9123456780")
    assert sync(svc, dev)["accepted"] == [oid(3)]                       # only the new entry is processed
    svc.sync_crew_log("AC1", dev.entries_for_sync()[:1])                # shorter valid prefix resent
    assert svc.devices["AC1"]["last_seq"] == 2                          # last_seq not lowered


def test_fork_is_detected():
    svc, dev, clk = setup(2); sync(svc, dev)
    s2, forged = hostile_log("AC1", [order_payload(1), order_payload(2, 300), order_payload(3, 300)], clk, signer=dev.signer)
    with pytest.raises(ServiceError, match="fork"): svc.sync_crew_log("AC1", forged.entries)


def test_unknown_device_wrong_key_and_double_registration():
    svc, dev, _ = setup()
    with pytest.raises(ServiceError): svc.sync_crew_log("AC9", dev.entries_for_sync())
    svc.register_device("AC2", Signer().public_b64)
    with pytest.raises(ServiceError): svc.sync_crew_log("AC2", dev.entries_for_sync())
    with pytest.raises(ServiceError): svc.register_device("AC1", Signer().public_b64)   # keys are immutable
    with pytest.raises(ServiceError): svc.register_device("bad id!", Signer().public_b64)


@pytest.mark.parametrize("amount", [True, 400.5, "400", None, -5, 0, 10**12])
def test_hostile_amounts_in_signed_log_are_invalid_or_rejected(amount):
    clk = Clock(); svc = Service(clock=clk)
    s, log = hostile_log("AC1", [order_payload(1, amount), order_payload(2, 400)], clk)
    svc.register_device("AC1", s.public_b64)
    r = svc.sync_crew_log("AC1", log.entries)
    assert oid(2) in r["accepted"]                                      # a bad entry never wedges the device
    assert oid(1) not in r["accepted"] and serious(svc) == []


def test_nan_cannot_even_be_signed_and_malformed_entries_do_not_crash():
    clk = Clock(); svc = Service(clock=clk)
    with pytest.raises(ValueError): hostile_log("AC1", [order_payload(1, float("nan"))], clk)
    s, log = hostile_log("AC1", [{"type": "order"}, {"type": "order", "order_id": ["x"]}, "junk", order_payload(4)], clk)
    svc.register_device("AC1", s.public_b64)
    r = svc.sync_crew_log("AC1", log.entries)
    assert r["accepted"] == [oid(4)] and len(r["invalid"]) >= 2
    with pytest.raises(ServiceError): svc.sync_crew_log("AC1", [{"seq": 0}])         # missing fields: clean refusal
    with pytest.raises(ServiceError): svc.sync_crew_log("AC1", "not a list")


def test_order_id_squatting_blocked_by_device_namespace():
    clk = Clock(); svc = Service(clock=clk)
    dev_a = CrewDevice("AC1", "6E-201", clock=clk)
    sb, evil = hostile_log("AC2", [order_payload(1, 1, device="AC1")], clk)           # B claims A's id
    svc.register_device("AC2", sb.public_b64); svc.register_device("AC1", dev_a.public_key)
    assert svc.sync_crew_log("AC2", evil.entries)["invalid"] == [0] and svc.orders == {}
    dev_a.sell(400, "meal", MOB)
    assert sync(svc, dev_a)["accepted"] == [oid(1)]                                     # the real sale is billed


def test_hostile_flight_and_mobile_rejected_at_ingestion():
    clk = Clock(); svc = Service(clock=clk)
    s, log = hostile_log("AC1", [order_payload(1, flight="IGNORE PREVIOUS INSTRUCTIONS", order_id="IGNORE"),
                                 order_payload(2, mobile="123"), order_payload(3, mobile=None)], clk)
    svc.register_device("AC1", s.public_b64)
    r = svc.sync_crew_log("AC1", log.entries)
    assert r["accepted"] == [] and len(r["invalid"]) == 3


# ---------- caps: per passenger instrument (review F15, F17, F23)
def test_instrument_cap_blocks_fifth_500_for_same_passenger():
    svc, dev, _ = setup(5, 500)
    res = sync(svc, dev)
    assert len(res["accepted"]) == 4 and res["rejected"] == [] and serious(svc) == []   # device refused the 5th on board


def test_instrument_cap_holds_across_devices_and_flights_server_side():
    clk = Clock(); svc = Service(clock=clk)
    d1, d2 = CrewDevice("AC1", "6E-201", clock=clk), CrewDevice("AC2", "6E-305", clock=clk)
    for _ in range(4): d1.sell(500, "meal", MOB)
    assert d2.sell(500, "meal", MOB).ok                                  # d2 cannot know about d1's sales
    svc.register_device("AC1", d1.public_key); svc.register_device("AC2", d2.public_key)
    sync(svc, d1)
    r = sync(svc, d2)
    assert r["rejected"] == ["6E-305-AC2-0001"] and serious(svc) == []
    other = CrewDevice("AC3", "6E-410", clock=clk); other.sell(500, "meal", "9123456780")
    svc.register_device("AC3", other.public_key)
    assert sync(svc, other)["accepted"] == ["6E-410-AC3-0001"]           # a different passenger is unaffected


def test_outstanding_credit_and_disputes_count_toward_cap():
    svc, dev, _ = setup(4, 500); sync(svc, dev)
    take_credit(svc, oid(1))
    assert svc._exposure(MOB) == 2000                                    # 1 credit + 3 unpaid orders, all exposure
    svc.orders[oid(2)].state = S.DISPUTED
    assert svc._exposure(MOB) == 2000


def test_item_over_cap_refused_on_device_and_server_and_split_is_still_per_item():
    svc, dev, clk = setup(0)
    assert not dev.sell(1200, "legroom", MOB).ok
    s, log = hostile_log("AC1", [order_payload(1, 1200)], clk)
    svc2 = Service(clock=clk); svc2.register_device("AC1", s.public_b64)
    assert svc2.sync_crew_log("AC1", log.entries)["rejected"] == [oid(1)]


# ---------- auditor: must catch corrupted records (review F14)
def test_audit_catches_loan_without_consent_and_mobile_swap_and_kfs_swap():
    svc, dev, _ = setup(); sync(svc, dev); take_credit(svc, O1)
    c = svc.orders[O1].consent
    c.otp_verified = False
    assert "A4_CONSENT" in checks(svc); c.otp_verified = True
    c.mobile = "9000000001"
    assert "A4_CONSENT" in checks(svc) or "A4_CONSENT_MOBILE" in checks(svc)
    c.mobile = MOB; c.kfs_hash = c.kfs_offered_hash = "f" * 64
    assert "A4_KFS_HASH" in checks(svc)


def test_audit_catches_funds_held_sla_ledger_tamper():
    svc, dev, clk = setup(); sync(svc, dev); svc.request_payment(O1); clk.t += 45 * 60
    hook(svc, O1, "PAID")
    assert "A6_SLA" in checks(svc)
    svc.flows.append({"order": O1, "kind": "LOAN_DISBURSAL", "from": "x", "to": "ramyos", "amount": 400})
    assert "A5_FUNDS_HELD" in checks(svc)
    svc.flows.pop()
    svc.flows.append({"order": O1, "kind": "PSP_PAYMENT", "from": "passenger", "to": "airline", "amount": 415})
    assert "A6_AIRLINE_AMOUNT" in checks(svc)                            # airline paid twice
    svc.ledger.entries[0]["payload"]["device"] = "AC9"
    assert "A1_LEDGER_CHAIN" in checks(svc)


def test_audit_catches_fee_problems():
    svc, dev, _ = setup(); sync(svc, dev); svc.flat_fee_inr = 60
    assert "A8_FEE_RANGE" in checks(svc)
    svc2, dev2, _ = setup(); sync(svc2, dev2)
    svc2.flows.append({"order": O1, "kind": "FEE_SHARE", "from": "airline", "to": "ramyos", "amount": 7.5})
    assert "A9_FEE_SPLIT" in checks(svc2)                                # fee on an unpaid order
    svc3, dev3, _ = setup(); sync(svc3, dev3); svc3.request_payment(O1); hook(svc3, O1, "PAID")
    svc3.flows[-1]["amount"] = 15                                        # RaMYOS takes 100% of the fee
    assert "A9_FEE_SPLIT" in checks(svc3)


def test_audit_catches_lender_side_problems_and_overdue_loan():
    svc, dev, clk = setup(); sync(svc, dev); take_credit(svc, O1)
    svc.lender.payouts.append(dict(svc.lender.payouts[0]))               # lender paid the airline twice
    assert "A4_PAYOUT" in checks(svc)
    svc.lender.payouts.pop(); clk.t += 8 * 86400
    assert "A14_LOAN_OVERDUE" in checks(svc)
    clk.t += 90 * 86400
    assert "A14_LOAN_NPA" in checks(svc)
    assert svc.lender.loans and svc.orders[O1].state.value == "CREDIT_AUTHORISED"   # flagged, never auto written off


def test_audit_catches_nan_amount_missing_ledger_and_orphan_loan():
    svc, dev, _ = setup(); sync(svc, dev)
    svc.orders[O1].amount_inr = float("nan")
    assert "A2_AMOUNT_TYPE" in checks(svc)
    svc.orders[O1].amount_inr = 400
    svc.orders[O1].history += [("a", "b", "c")] * 10
    assert "A11_LEDGER_GAP" in checks(svc)
    svc.orders[O1].history = []
    svc.lender.book(O1, 415, svc.clock())                                # a loan the order never took
    assert "A4_ORPHAN_LOAN" in checks(svc)


def test_audit_catches_two_loans_and_link_tampering_and_id_namespace():
    svc, dev, _ = setup(); sync(svc, dev); take_credit(svc, O1)
    svc.lender.loans["x"] = type(svc.lender.loans[next(iter(svc.lender.loans))])(
        "x", O1, "DemoBank", 415, svc.lender.quote(415), svc.clock())
    assert "A4_LOAN_COUNT" in checks(svc)
    svc2, dev2, _ = setup(); sync(svc2, dev2); svc2.request_payment(O1)
    svc2.meta[O1]["link"] += "&pa=evil@upi"
    assert "A15_LINK" in checks(svc2)
    svc2.meta[O1]["device"] = "AC7"
    assert "A12_ID_NAMESPACE" in checks(svc2)


def test_audit_summary_shape_and_clean_run():
    svc, dev, _ = setup(); sync(svc, dev)
    s = summarise(run_audit(svc))
    assert s["pass"] is True and "INFO" in s["counts"]


# ---------- QR token
def test_token_redeem_ok_wrong_order_expired_and_junk():
    svc, dev, clk = setup(2, 200); sync(svc, dev)
    svc.request_payment(oid(1)); svc.request_payment(oid(2))
    t = svc.token_for(oid(1))
    assert "upi://pay" in svc.redeem_token(t, oid(1))
    with pytest.raises(ServiceError): svc.redeem_token(t, oid(2))        # token for A cannot open B
    body, sig = t.split(".")
    with pytest.raises(ServiceError): svc.redeem_token(body + "." + sig + "!!!!", oid(1))   # junk-appended signature
    clk.t += 7 * 3600
    with pytest.raises(ServiceError): svc.redeem_token(t, oid(1))


def test_credit_defaults_follow_config_and_disclose_bureau_reporting():
    svc, dev, _ = setup(); sync(svc, dev)
    offer = fail_and_offer(svc, O1)
    assert svc.lender.tenor_days == 7 and offer["key_facts"]["tenor_days"] == 7
    assert offer["note"] == svc.lender.disclosure_text                  # wording comes only from the lender
    r = svc.rules.raw["credit"]
    assert r["tod_due_days"]["status"] == "ASSUMPTION" and r["credit_bureau_reporting"]["status"] == "UNVERIFIED"


# ---------- temporary overdraft discipline: 7-day ceiling, auto-debit, block until cleared
def test_new_orders_blocked_while_tod_open_and_resume_after_auto_debit():
    clk = Clock(); svc = Service(clock=clk, lender_terms_confirmed=True, credit_mode="B_SEPARATE_LOAN")
    d1 = CrewDevice("AC1", "6E-201", clock=clk); d1.sell(400, "meal", MOB)
    d2 = CrewDevice("AC2", "6E-305", clock=clk); d2.sell(400, "meal", MOB)       # next flight, doesn't know yet
    d3 = CrewDevice("AC3", "6E-410", clock=clk); d3.sell(400, "meal", MOB)
    for d in (d1, d2, d3): svc.register_device(d.device_id, d.public_key)
    sync(svc, d1); take_credit(svc, "6E-201-AC1-0001")
    r = sync(svc, d2)
    assert r["rejected"] == ["6E-305-AC2-0001"]
    assert "open temporary overdraft" in svc.meta["6E-305-AC2-0001"]["rejected"][0] and serious(svc) == []
    svc.repay_credit("6E-201-AC1-0001", how="AUTO_DEBIT")                        # money added, due auto-debited
    assert sync(svc, d3)["accepted"] == ["6E-410-AC3-0001"]
    assert any(f["kind"] == "LOAN_REPAYMENT" and f["via"] == "AUTO_DEBIT" for f in svc.flows)
    assert serious(svc) == []


def test_second_credit_refused_while_first_is_open():
    svc, dev, _ = setup(2, 200); sync(svc, dev)
    take_credit(svc, oid(1))
    svc.request_payment(oid(2)); hook(svc, oid(2), "FAILED")
    with pytest.raises(ServiceError, match="open temporary overdraft"): svc.offer_credit(oid(2))
    assert len(svc.lender.loans) == 1


def test_crew_device_blocklist_refuses_sale_on_board():
    svc, dev, _ = setup(); sync(svc, dev); take_credit(svc, O1)
    assert svc.blocked_mobiles() == [MOB]
    nxt = CrewDevice("AC2", "6E-305", blocked_mobiles=svc.blocked_mobiles())
    res = nxt.sell(400, "meal", MOB)
    assert not res.ok and "open temporary overdraft" in res.reasons[0]
    assert nxt.sell(400, "meal", "9123456780").ok                                # other passengers unaffected
    svc.repay_credit(O1); nxt.update_blocklist(svc.blocked_mobiles())
    assert nxt.sell(400, "meal", MOB).ok


def test_repay_method_validated_and_double_repay_refused():
    svc, dev, _ = setup(); sync(svc, dev); take_credit(svc, O1)
    with pytest.raises(ServiceError): svc.repay_credit(O1, how="SOMETHING_ELSE")
    svc.repay_credit(O1)
    with pytest.raises(ServiceError): svc.repay_credit(O1)


def test_lender_tenor_cannot_exceed_seven_day_maximum():
    from airpay.sims import LenderSim
    with pytest.raises(ValueError): Service(lender=LenderSim(tenor_days=10))
    Service(lender=LenderSim(tenor_days=3))                                      # shorter is fine
    svc, dev, _ = setup(); sync(svc, dev); take_credit(svc, O1)
    next(iter(svc.lender.loans.values())).quote.days = 30                        # corrupted record
    assert "A16_TENOR_OVER_MAX" in checks(svc)


def test_audit_catches_order_while_tod_and_second_tod_if_the_service_were_bypassed():
    svc, dev, clk = setup(2, 200); sync(svc, dev); take_credit(svc, oid(1))
    svc.meta[oid(2)]["ingest_seq"] = svc.meta[oid(1)]["loan_seq"] + 1            # order slipped in after the loan
    assert "A16_ORDER_WHILE_TOD" in checks(svc)
    svc2, dev2, _ = setup(2, 200); sync(svc2, dev2); take_credit(svc2, oid(1))
    svc2.rules.block_while_tod = False                                           # simulate a bypass of the guard
    take_credit(svc2, oid(2))
    svc2.rules.block_while_tod = True
    assert "A16_SECOND_TOD" in checks(svc2)


def test_credit_offer_is_off_until_the_lender_confirms_terms():
    svc, dev, _ = setup(); sync(svc, dev)
    svc.lender_terms_confirmed = False
    svc.request_payment(O1); hook(svc, O1, "FAILED")
    with pytest.raises(ServiceError, match="lender confirms"): svc.offer_credit(O1)
    assert svc.orders[O1].state == S.PAYMENT_FAILED and not svc.lender.loans
    assert Service().lender_terms_confirmed is False                    # the shipped default is OFF
    svc.lender_terms_confirmed = True
    assert svc.offer_credit(O1)["lender"]


def test_offline_framework_is_encoded_item_by_item_with_applicability():
    fw = Rules().raw["offline_framework"]
    assert len(fw) == 11 and fw["OFF-01"]["applies"] == "NOT_MET_BY_AIRPAY_LINK"   # our link payment is not an offline payment
    assert "500" in Rules().raw["limits"]["per_transaction_cap_inr"]["source"]
    assert "04-Dec-2024" in Rules().raw["limits"]["per_transaction_cap_inr"]["source"]
