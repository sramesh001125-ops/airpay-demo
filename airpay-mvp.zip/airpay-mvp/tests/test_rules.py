import pytest

from airpay.rules import Rules


def test_single_400_item_allowed():
    assert Rules().check_order([400], 0).allowed


def test_item_over_500_refused_not_split():
    d = Rules().check_order([1200], 0)
    assert not d.allowed and "LIM-03" in d.rule_ids


def test_instrument_cap_2000_blocks_fifth_500_order():
    r = Rules()
    assert r.check_order([500], 1500).allowed
    d = r.check_order([500], 1600)
    assert not d.allowed and "LIM-02" in d.rule_ids


@pytest.mark.parametrize("bad", [[], [0], [-1], [True], [400.5], [float("nan")], [float("inf")], ["400"], [None], 400])
def test_non_rupee_amounts_refused(bad):
    assert not Rules().check_order(bad, 0).allowed


@pytest.mark.parametrize("open_", [-1, 1.5, float("nan"), True, "0", None])
def test_bad_exposure_refused(open_):
    assert not Rules().check_order([400], open_).allowed


def test_rules_file_marks_applicability_honestly():
    r = Rules().raw["limits"]
    assert r["per_transaction_cap_inr"]["status"] != "VERIFIED" and r["per_instrument_cap_inr"]["status"] != "VERIFIED"
