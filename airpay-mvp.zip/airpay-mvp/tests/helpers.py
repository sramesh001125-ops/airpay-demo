from airpay.audit import run_audit
from airpay.crypto import CrewLog, Signer
from airpay.pos.crew_device import CrewDevice
from airpay.service import Service
from airpay.sims import psp_sign

MOB = "9876543210"


class Clock:
    def __init__(self):
        self.t = 1_000_000.0

    def __call__(self):
        return self.t


def oid(i=1, device="AC1", flight="6E-201"):
    return f"{flight}-{device}-{i:04d}"


def setup(n=1, amount=400, mobile=MOB):
    clk = Clock()
    svc = Service(clock=clk, lender_terms_confirmed=True, credit_mode="B_SEPARATE_LOAN")
    dev = CrewDevice("AC1", "6E-201", clock=clk)
    for _ in range(n):
        dev.sell(amount, "meal", mobile)
    svc.register_device("AC1", dev.public_key)
    return svc, dev, clk


def sync(svc, dev):
    return svc.sync_crew_log(dev.device_id, dev.entries_for_sync())


def hook(svc, o, status, attempt=None, amount=None, ts=None):
    attempt = svc.meta[o]["attempt"] if attempt is None else attempt
    amount = svc.orders[o].total_due if amount is None else amount
    ts = int(svc.clock()) if ts is None else ts
    return svc.psp_webhook(o, attempt, status, amount, ts, psp_sign(o, attempt, status, amount, ts))


def fail_and_offer(svc, o):
    svc.request_payment(o)
    hook(svc, o, "FAILED")
    return svc.offer_credit(o)


def take_credit(svc, o):
    offer = fail_and_offer(svc, o)
    code = svc.send_otp(o)
    return svc.authorise_credit(o, True, code, offer["kfs_hash"])


def serious(svc):
    return [x for x in run_audit(svc) if x.severity in ("CRITICAL", "HIGH")]


def checks(svc):
    return {x.check for x in serious(svc)}


def hostile_log(device, payloads, clk=None, signer=None):
    """A correctly signed log carrying arbitrary (possibly hostile) payloads: models a compromised/cloned device."""
    s = signer or Signer()
    log = CrewLog(device, s)
    for p in payloads:
        log.append(p, ts=(clk.t if clk else 1000.0))
    return s, log


def order_payload(i=1, amount=400, device="AC1", flight="6E-201", mobile=MOB, **over):
    p = {"type": "order", "order_id": oid(i, device, flight), "flight": flight, "amount_inr": amount,
         "mobile": mobile}
    p.update(over)
    return p
