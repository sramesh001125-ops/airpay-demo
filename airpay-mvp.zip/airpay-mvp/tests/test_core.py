import copy
import pytest

from airpay.crypto import CrewLog, Signer, make_token, read_token, verify_chain
from airpay.fees import CreditQuote, service_fee_split
from airpay.orders import Consent, Order, S, TransitionError


def _log(n=3):
    s = Signer(); log = CrewLog("AC-1", s)
    for i in range(n):
        log.append({"order": f"o{i}", "amount": 400}, ts=1000 + i)
    return s, log


def test_chain_ok():
    s, log = _log()
    assert verify_chain(log.entries, s.public_b64)[0]


def test_tamper_amount_detected():
    s, log = _log(); e = copy.deepcopy(log.entries)
    e[1]["payload"]["amount"] = 40
    assert not verify_chain(e, s.public_b64)[0]


def test_delete_and_reorder_detected():
    s, log = _log(); e = copy.deepcopy(log.entries)
    assert not verify_chain(e[:1] + e[2:], s.public_b64)[0]
    assert not verify_chain([e[1], e[0], e[2]], s.public_b64)[0]


def test_wrong_key_rejected():
    _, log = _log()
    assert not verify_chain(log.entries, Signer().public_b64)[0]


def test_token_roundtrip_expiry_and_tamper():
    s = Signer(); t = make_token({"o": "x", "amt": 400, "exp": 2000}, s)
    assert read_token(t, s.public_b64, now=1500)[0]
    assert read_token(t, s.public_b64, now=2500) == (False, "token expired")
    body, sig = t.split(".")
    assert not read_token("A" + body[1:] + "." + sig, s.public_b64, now=1500)[0]


def _consent(**kw):
    base = dict(box_ticked=True, otp_verified=True, kfs_hash="h", kfs_offered_hash="h", mobile="9876543210")
    base.update(kw)
    return Consent(**base)


def _offered():
    o = Order("o1", "6E-1", 400, fee_inr=15, mobile="9876543210")
    o.go(S.PAYMENT_REQUESTED, "system"); o.go(S.PAYMENT_FAILED, "psp"); o.go(S.CREDIT_OFFERED, "system")
    return o


def test_credit_needs_valid_consent():
    o = _offered()
    for bad in (_consent(otp_verified=False), _consent(box_ticked=False), _consent(kfs_hash=""),
                _consent(kfs_hash="other"), _consent(mobile=""), _consent(mobile="9000000001")):
        with pytest.raises(TransitionError):
            o.go(S.CREDIT_AUTHORISED, "passenger", bad)
    with pytest.raises(TransitionError):
        o.go(S.CREDIT_AUTHORISED, "system", _consent())
    o.go(S.CREDIT_AUTHORISED, "passenger", _consent())
    assert o.state == S.CREDIT_AUTHORISED


def test_no_auto_loan_from_failed_or_recorded():
    o = Order("o2", "6E-1", 400, mobile="9876543210")
    with pytest.raises(TransitionError):
        o.go(S.CREDIT_AUTHORISED, "passenger", _consent())
    o.go(S.PAYMENT_REQUESTED, "system"); o.go(S.PAYMENT_FAILED, "psp")
    with pytest.raises(TransitionError):
        o.go(S.CREDIT_AUTHORISED, "passenger", _consent())


def test_paid_cannot_be_cancelled():
    o = Order("o3", "6E-1", 400, mobile="9876543210")
    o.go(S.PAYMENT_REQUESTED, "system"); o.go(S.PAID_VERIFIED, "psp")
    with pytest.raises(TransitionError):
        o.go(S.CANCELLED, "crew")


def test_apr_and_fee_split():
    q = CreditQuote(400, 20, 5)
    assert q.apr_pct == 365.0 and q.total_repayable_inr == 420
    assert service_fee_split(20) == {"fee_inr": 20, "airline_inr": 10.0, "ramyos_inr": 10.0}
