from fastapi.testclient import TestClient

from airpay import api

c = TestClient(api.app)


def fresh():
    c.post("/api/demo/reset")


def first(r):
    return r.json()["synced"]["accepted"][0]


def test_full_flow_over_http():
    c.post("/api/demo/mode", json={"mode": "B_SEPARATE_LOAN"})
    oid = first(c.post("/api/demo/flight", json={"orders": [400]}))
    assert c.post(f"/api/orders/{oid}/link").status_code == 200
    assert c.post(f"/api/orders/{oid}/psp", json={"status": "FAILED"}).json()["state"] == "PAYMENT_FAILED"
    offer = c.post(f"/api/orders/{oid}/offer").json()
    assert offer["key_facts"]["total_repayable_inr"] == 430 and offer["key_facts"]["principal_inr"] == 415
    code = c.post(f"/api/orders/{oid}/otp").json()["demo_code"]
    bad = c.post(f"/api/orders/{oid}/authorise", json={"box": False, "otp": code, "kfs_hash": offer["kfs_hash"]})
    assert bad.status_code == 400
    wrong = c.post(f"/api/orders/{oid}/authorise", json={"box": True, "otp": code, "kfs_hash": "0" * 64})
    assert wrong.status_code == 400
    ok = c.post(f"/api/orders/{oid}/authorise", json={"box": True, "otp": code, "kfs_hash": offer["kfs_hash"]})
    assert ok.status_code == 200 and ok.json()["airline_paid"] == 415
    assert c.get("/api/audit").json()["verdict_pass"] is True
    assert c.post(f"/api/orders/{oid}/repay").json()["repaid"] == 430


def test_http_blocks_credit_before_failure_and_unknown_order():
    fresh()
    oid = first(c.post("/api/demo/flight", json={"orders": [400]}))
    assert c.post(f"/api/orders/{oid}/offer").status_code == 400
    assert c.post("/api/orders/nope/link").status_code == 400


def test_sla_breach_fails_audit_and_ui_served():
    fresh()
    oid = first(c.post("/api/demo/flight", json={"orders": [400]}))
    c.post(f"/api/orders/{oid}/link"); c.post("/api/demo/advance", json={"minutes": 45})
    c.post(f"/api/orders/{oid}/psp", json={"status": "PAID"})
    assert c.get("/api/audit").json()["verdict_pass"] is False
    assert "RaMYOS AirPay" in c.get("/").text


def test_same_passenger_capped_at_2000_over_http():
    fresh()
    r = c.post("/api/demo/flight", json={"orders": [500] * 5}).json()
    assert len(r["synced"]["accepted"]) == 4 and [s["ok"] for s in r["sold_on_board"]] == [True] * 4 + [False]


def test_demo_endpoints_are_off_when_demo_flag_is_off(monkeypatch):
    fresh()
    oid = first(c.post("/api/demo/flight", json={"orders": [400]}))
    c.post(f"/api/orders/{oid}/link")
    monkeypatch.setenv("AIRPAY_DEMO", "0")
    assert c.post("/api/demo/reset").status_code == 404
    assert c.post(f"/api/orders/{oid}/psp", json={"status": "PAID"}).status_code == 404   # no signing on a caller's behalf
    assert c.post("/api/demo/advance", json={"minutes": 5}).status_code == 404
    assert c.post("/api/agents/kill").status_code == 404
    c.post(f"/api/orders/{oid}/link")  # still reachable user paths work or fail cleanly, never 500
    monkeypatch.setenv("AIRPAY_DEMO", "1")


def test_input_validation_negative_clock_and_bad_json():
    fresh()
    assert c.post("/api/demo/advance", json={"minutes": -99999}).status_code == 422
    assert c.post("/api/demo/flight", json={"orders": [400] * 51}).status_code == 422
    oid = first(c.post("/api/demo/flight", json={"orders": [400]}))
    assert c.post(f"/api/orders/{oid}/authorise", json={"box": True}).status_code == 422


def test_mode_a_over_http():
    c.post("/api/demo/mode", json={"mode": "A_SB_OVERDRAFT"})
    oid = first(c.post("/api/demo/flight", json={"orders": [400]}))
    c.post(f"/api/orders/{oid}/link")
    assert c.post(f"/api/orders/{oid}/offer").status_code == 400          # AirPay offers no credit in Mode A
    assert c.post(f"/api/orders/{oid}/psp", json={"status": "PAID"}).json()["state"] == "PAID_VERIFIED"
    assert c.post(f"/api/orders/{oid}/bank", json={"event": "TOD_OPENED"}).status_code == 200
    assert c.get("/api/audit").json()["verdict_pass"] is True
    assert c.post(f"/api/orders/{oid}/bank", json={"event": "TOD_CLEARED"}).json()["state"] == "TOD_CLEARED"
    assert c.get("/api/audit").json()["verdict_pass"] is True
    c.post("/api/demo/mode", json={"mode": "B_SEPARATE_LOAN"})
