"""Fee and APR calculators. Figures shown to a passenger must come from here, never typed by hand."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CreditQuote:
    principal_inr: float
    total_charges_inr: float     # every charge the passenger pays on the credit (interest + fees)
    days: int

    @property
    def apr_pct(self) -> float:
        """Simple annualised rate on total charges. A short tenor makes this very large, so it is
        always shown to the passenger. Confirm the exact APR definition with the lender and the
        Digital Lending Directions before any live use."""
        return round(self.total_charges_inr / self.principal_inr * 365 / self.days * 100, 2)

    @property
    def total_repayable_inr(self) -> float:
        return round(self.principal_inr + self.total_charges_inr, 2)

    def key_facts(self) -> dict:
        return {"principal_inr": self.principal_inr, "total_charges_inr": self.total_charges_inr,
                "total_repayable_inr": self.total_repayable_inr, "tenor_days": self.days,
                "apr_pct": self.apr_pct}


def service_fee_split(fee_inr: float, airline_share_pct: float = 50.0) -> dict:
    a = round(fee_inr * airline_share_pct / 100, 2)
    return {"fee_inr": fee_inr, "airline_inr": a, "ramyos_inr": round(fee_inr - a, 2)}
