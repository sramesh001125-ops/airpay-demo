"""Order state machine. Credit can never be reached without explicit, recorded consent."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class S(str, Enum):
    PURCHASE_RECORDED = "PURCHASE_RECORDED"
    PAYMENT_REQUESTED = "PAYMENT_REQUESTED"
    PAID_VERIFIED = "PAID_VERIFIED"
    PAYMENT_FAILED = "PAYMENT_FAILED"
    CREDIT_OFFERED = "CREDIT_OFFERED"
    CREDIT_AUTHORISED = "CREDIT_AUTHORISED"
    DISPUTED = "DISPUTED"
    CANCELLED = "CANCELLED"
    WRITTEN_OFF = "WRITTEN_OFF"


ALLOWED: dict[S, set[S]] = {
    S.PURCHASE_RECORDED: {S.PAYMENT_REQUESTED, S.CANCELLED, S.DISPUTED},
    S.PAYMENT_REQUESTED: {S.PAID_VERIFIED, S.PAYMENT_FAILED, S.CANCELLED, S.DISPUTED},
    # a "failed" UPI payment can still succeed late: money really moved, so PAID_VERIFIED must be reachable
    S.PAYMENT_FAILED: {S.PAYMENT_REQUESTED, S.PAID_VERIFIED, S.CREDIT_OFFERED, S.WRITTEN_OFF, S.DISPUTED},
    S.CREDIT_OFFERED: {S.CREDIT_AUTHORISED, S.PAYMENT_REQUESTED, S.PAID_VERIFIED, S.WRITTEN_OFF, S.DISPUTED},
    # CREDIT_AUTHORISED -> PAID_VERIFIED means the LOAN WAS REPAID (service.repay_credit), never a link payment
    S.CREDIT_AUTHORISED: {S.PAID_VERIFIED, S.DISPUTED},
    S.PAID_VERIFIED: {S.DISPUTED},
    S.DISPUTED: {S.PAID_VERIFIED, S.CANCELLED, S.WRITTEN_OFF},
    S.CANCELLED: set(),
    S.WRITTEN_OFF: set(),
}


class TransitionError(Exception):
    pass


@dataclass
class Consent:
    box_ticked: bool = False
    otp_verified: bool = False
    kfs_hash: str = ""            # hash of the key fact statement the passenger acknowledged
    kfs_offered_hash: str = ""    # hash of the key fact statement the server actually offered
    mobile: str = ""
    at: float = 0.0

    def valid(self) -> bool:
        return (self.box_ticked is True and self.otp_verified is True and bool(self.kfs_hash)
                and self.kfs_hash == self.kfs_offered_hash and bool(self.mobile))


@dataclass
class Order:
    order_id: str
    flight: str
    amount_inr: int                 # item price
    fee_inr: int = 0                # flat service fee, part of what the passenger pays
    mobile: str = ""                # passenger's phone = the payment instrument
    state: S = S.PURCHASE_RECORDED
    history: list[tuple[str, str, str]] = field(default_factory=list)  # (from, to, actor)
    consent: Consent | None = None

    @property
    def total_due(self) -> int:
        return self.amount_inr + self.fee_inr

    def go(self, to: S, actor: str, consent: Consent | None = None) -> None:
        if to not in ALLOWED[self.state]:
            raise TransitionError(f"{self.state.value} -> {to.value} not allowed")
        if to == S.CREDIT_AUTHORISED:
            if actor != "passenger":
                raise TransitionError("only the passenger can authorise credit")
            if consent is None or not consent.valid():
                raise TransitionError("credit needs box tick, OTP, matching key fact statement and mobile")
            if consent.mobile != self.mobile:
                raise TransitionError("consent mobile does not match the order's passenger")
            self.consent = consent
        self.history.append((self.state.value, to.value, actor))
        self.state = to
