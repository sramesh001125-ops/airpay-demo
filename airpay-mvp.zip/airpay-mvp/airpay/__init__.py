"""RaMYOS AirPay - in-flight order, post-landing UPI link and consent-based short credit (MVP core)."""
__version__ = "0.1.0"
