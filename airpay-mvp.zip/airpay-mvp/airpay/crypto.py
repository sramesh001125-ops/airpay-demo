"""Ed25519 signing, hash-chained crew log, and self-contained signed QR tokens."""
from __future__ import annotations

import base64
import hashlib
import json
import time

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

GENESIS = "0" * 64
TOKEN_DOMAIN = b"airpay-token-v1|"      # domain separation: a log signature can never be replayed as a token


def b64e(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def b64d(s: str) -> bytes:
    """Strict: any character outside the base64url alphabet is an error (no silent junk-skipping)."""
    if not isinstance(s, str):
        raise ValueError("not a string")
    return base64.b64decode(s.replace("-", "+").replace("_", "/") + "=" * (-len(s) % 4), validate=True)


def canon(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


class Signer:
    def __init__(self, private: Ed25519PrivateKey | None = None):
        self._priv = private or Ed25519PrivateKey.generate()

    @property
    def public_b64(self) -> str:
        raw = self._priv.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return b64e(raw)

    def sign(self, data: bytes) -> str:
        return b64e(self._priv.sign(data))


def verify(public_b64: str, data: bytes, sig_b64: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(b64d(public_b64)).verify(b64d(sig_b64), data)
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def _entry_hash(device: str, seq: int, prev: str, ts: float, payload: dict) -> str:
    # the device id is inside the hash, so an entry cannot be moved to another device's log
    return hashlib.sha256(canon({"device": device, "seq": seq, "prev": prev, "ts": ts,
                                 "payload": payload})).hexdigest()


class CrewLog:
    """Append-only, signed, hash-chained log kept on the crew device while offline.
    Editing, deleting, reordering or inserting any entry breaks verification."""

    def __init__(self, device_id: str, signer: Signer):
        self.device_id = device_id
        self.signer = signer
        self.entries: list[dict] = []

    def append(self, payload: dict, ts: float | None = None) -> dict:
        seq = len(self.entries)
        prev = self.entries[-1]["hash"] if self.entries else GENESIS
        ts = time.time() if ts is None else ts
        h = _entry_hash(self.device_id, seq, prev, ts, payload)
        e = {"seq": seq, "prev": prev, "ts": ts, "payload": payload, "hash": h,
             "device": self.device_id, "sig": self.signer.sign(h.encode())}
        self.entries.append(e)
        return e


def verify_chain(entries: list[dict], public_b64: str) -> tuple[bool, str]:
    prev = GENESIS
    i = -1
    try:
        for i, e in enumerate(entries):
            if e["seq"] != i:
                return False, f"entry {i}: sequence gap or reorder"
            if e["prev"] != prev:
                return False, f"entry {i}: broken chain"
            if _entry_hash(e["device"], e["seq"], e["prev"], e["ts"], e["payload"]) != e["hash"]:
                return False, f"entry {i}: content altered"
            if not verify(public_b64, e["hash"].encode(), e["sig"]):
                return False, f"entry {i}: bad signature"
            prev = e["hash"]
    except (KeyError, TypeError, ValueError, AttributeError) as ex:
        return False, f"entry {i}: malformed ({type(ex).__name__})"
    return True, "ok"


def make_token(payload: dict, signer: Signer) -> str:
    body = b64e(canon(payload))
    return f"{body}.{signer.sign(TOKEN_DOMAIN + body.encode())}"


def read_token(token: str, public_b64: str, now: float | None = None) -> tuple[bool, dict | str]:
    """Returns (True, payload) or (False, reason). Payload must carry `exp` (epoch seconds)."""
    try:
        body, sig = token.split(".")
    except (ValueError, AttributeError):
        return False, "malformed token"
    if not verify(public_b64, TOKEN_DOMAIN + body.encode(), sig):
        return False, "bad signature"
    payload = json.loads(b64d(body))
    if (now if now is not None else time.time()) > payload.get("exp", 0):
        return False, "token expired"
    return True, payload
