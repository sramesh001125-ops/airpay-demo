"""POS adapter: maps a card-machine style sale message to a CrewDevice sale.

STATUS: interface only. Real terminals (the airlines' current card machines) each have their own SDK / message
format and certification process; this adapter fixes WHAT we need from them, not how a vendor delivers it:
terminal id, amount, item code, timestamp, passenger mobile (the payment instrument), optional seat.
Whether an existing terminal can run our app, or must be replaced by an aircraft mobile, is an OPEN item."""
from __future__ import annotations

from .crew_device import CrewDevice, SaleResult

REQUIRED = ("terminal_id", "amount_inr", "item_code", "mobile")


def from_pos_message(device: CrewDevice, msg: dict) -> SaleResult:
    if not isinstance(msg, dict):
        return SaleResult(False, reasons=["message must be an object"])
    missing = [k for k in REQUIRED if k not in msg]
    if missing:
        return SaleResult(False, reasons=[f"missing fields: {', '.join(missing)}"])
    if msg["terminal_id"] != device.device_id:
        return SaleResult(False, reasons=["message is from a different terminal"])
    return device.sell(msg["amount_inr"], msg["item_code"], msg["mobile"], msg.get("seat", ""))
