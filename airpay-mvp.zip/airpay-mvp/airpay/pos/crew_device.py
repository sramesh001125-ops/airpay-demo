"""On-aircraft device logic: works with NO network. Used by the crew mobile app, and by the POS adapter.
Enforces the same rules as the server at the moment of sale, so nothing is served that the server
would later have to reject. Exposure is tracked per PASSENGER MOBILE (the instrument), not per crew device."""
from __future__ import annotations

import re
import time
from dataclasses import dataclass

from ..crypto import CrewLog, Signer
from ..rules import Rules

FLIGHT_RE = re.compile(r"^[A-Z0-9]{2}-\d{1,4}$")
DEVICE_RE = re.compile(r"^[A-Z0-9]{1,12}$")
MOBILE_RE = re.compile(r"^[6-9]\d{9}$")


@dataclass
class SaleResult:
    ok: bool
    order_id: str = ""
    reasons: list[str] | None = None


class CrewDevice:
    def __init__(self, device_id: str, flight: str, rules: Rules | None = None,
                 signer: Signer | None = None, clock=time.time, blocked_mobiles=None):
        if not DEVICE_RE.match(device_id) or not FLIGHT_RE.match(flight):
            raise ValueError("device id or flight in invalid format")
        self.device_id, self.flight = device_id, flight
        self.rules = rules or Rules()
        self.signer = signer or Signer()
        self.log = CrewLog(device_id, self.signer)
        self.clock = clock
        self.blocked = set(blocked_mobiles or [])   # synced before the flight from the server
        self._open: dict[str, int] = {}     # passenger mobile -> value sold on this flight so far
        self._n = 0

    @property
    def public_key(self) -> str:
        return self.signer.public_b64

    def sell(self, amount_inr, item: str, passenger_mobile: str, seat: str = "") -> SaleResult:
        if not (isinstance(passenger_mobile, str) and MOBILE_RE.match(passenger_mobile)):
            return SaleResult(False, reasons=["passenger mobile number is required (it is the payment instrument)"])
        if passenger_mobile in self.blocked:
            return SaleResult(False, reasons=["passenger has an open temporary overdraft; it must be cleared first"])
        dec = self.rules.check_order([amount_inr], self._open.get(passenger_mobile, 0))
        if not dec.allowed:
            return SaleResult(False, reasons=dec.reasons)
        if self._n >= 9999:
            return SaleResult(False, reasons=["order counter exhausted for this device"])
        self._n += 1
        oid = f"{self.flight}-{self.device_id}-{self._n:04d}"
        self.log.append({"type": "order", "order_id": oid, "flight": self.flight, "amount_inr": amount_inr,
                         "item": str(item)[:60], "seat": str(seat)[:4], "mobile": passenger_mobile},
                        ts=self.clock())
        self._open[passenger_mobile] = self._open.get(passenger_mobile, 0) + amount_inr
        return SaleResult(True, oid)

    def update_blocklist(self, mobiles) -> None:
        self.blocked = set(mobiles)

    def entries_for_sync(self) -> list[dict]:
        return list(self.log.entries)
