"""Demo API. One in-memory world; /api/demo/* endpoints simulate the aircraft, PSP and clock.

NOT FOR PRODUCTION. Demo-only endpoints (demo/*, /psp, the OTP echo) are disabled unless AIRPAY_DEMO=1.
A production build must: accept payment callbacks only from the PSP's own signing key (never sign on a caller's
behalf), authenticate every caller, bind passenger actions to a passenger session proven by OTP to the order's
mobile, persist state, and never return an OTP. See docs/issues_log.md."""
from __future__ import annotations

import os
import pathlib

from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .agents.audit_agent import run_audit_agent
from .agents.llm import FakeLLM, GeminiLLM
from .agents.runtime import Runtime
from .pos.crew_device import CrewDevice
from .service import Service
from .sims import bank_sign, psp_sign

WEB = pathlib.Path(__file__).resolve().parent.parent / "web"
app = FastAPI(title="RaMYOS AirPay MVP")


def demo_only():
    if os.environ.get("AIRPAY_DEMO", "1") != "1":
        raise HTTPException(404, "not available")


class World:
    def __init__(self, mode: str = "A_SB_OVERDRAFT"):
        self.t = 1_800_000_000.0
        # DEMO ONLY: the credit offer is normally OFF until a real lender confirms terms (CR-05).
        self.svc = Service(clock=lambda: self.t, lender_terms_confirmed=True, credit_mode=mode)
        self.rt = Runtime(GeminiLLM() if os.environ.get("GEMINI_API_KEY") else FakeLLM(
            "(Demo mode: no GEMINI_API_KEY set, so no model narrative. The pass/fail verdict and findings "
            "above come from the deterministic auditor.)"))
        self.flights = 0


W = World()


def err(e: Exception):
    raise HTTPException(400, str(e))


class Flight(BaseModel):
    orders: list[int] = Field(default=[400, 400, 400], max_length=50)
    mobile: str = "9876543210"


class Psp(BaseModel):
    status: str


class Auth(BaseModel):
    box: bool
    otp: str
    kfs_hash: str


class Mode(BaseModel):
    mode: str


class Bank(BaseModel):
    event: str


class Adv(BaseModel):
    minutes: int = Field(ge=0, le=7 * 24 * 60)


@app.post("/api/demo/reset", dependencies=[Depends(demo_only)])
def reset():
    global W
    W = World(W.svc.credit_mode)
    return {"ok": True}


@app.post("/api/demo/mode", dependencies=[Depends(demo_only)])
def set_mode(m: Mode):
    global W
    if m.mode not in ("A_SB_OVERDRAFT", "B_SEPARATE_LOAN"):
        raise HTTPException(422, "unknown mode")
    W = World(m.mode)
    return {"mode": m.mode}


@app.post("/api/orders/{oid}/bank", dependencies=[Depends(demo_only)])
def bank(oid: str, b: Bank):
    """DEMO ONLY: plays the partner bank in Mode A, signing its own overdraft events."""
    try:
        ts = int(W.t)
        ref = f"TOD-{oid[-9:]}"
        if b.event == "TOD_OPENED":
            ch = int(W.svc.lender.charges_inr)
            return {"state": W.svc.bank_tod_opened(oid, ref, ch, ts, bank_sign(oid, "TOD_OPENED", ref, ch, ts))}
        if b.event == "TOD_CLEARED":
            ref = W.svc.meta[oid]["tod"]["ref"]
            return {"state": W.svc.bank_tod_cleared(oid, ref, ts, bank_sign(oid, "TOD_CLEARED", ref, 0, ts))}
        raise HTTPException(422, "unknown event")
    except HTTPException:
        raise
    except Exception as e:
        err(e)


@app.post("/api/demo/flight", dependencies=[Depends(demo_only)])
def flight(f: Flight):
    W.flights += 1
    dev = CrewDevice(f"AC{W.flights}", f"6E-{200 + W.flights}", clock=lambda: W.t)
    sold = [dev.sell(a, "meal", f.mobile).__dict__ for a in f.orders]
    try:
        W.svc.register_device(dev.device_id, dev.public_key)
        synced = W.svc.sync_crew_log(dev.device_id, dev.entries_for_sync())
    except Exception as e:
        err(e)
    return {"device": dev.device_id, "sold_on_board": sold, "synced": synced}


@app.post("/api/demo/advance", dependencies=[Depends(demo_only)])
def advance(a: Adv):
    W.t += a.minutes * 60
    return {"now": W.t}


@app.get("/api/state")
def state():
    s = W.svc
    return {"orders": [{"id": i, "flight": o.flight, "amount": o.amount_inr, "fee": o.fee_inr,
                        "total_due": o.total_due, "state": o.state.value, "rejected": s.meta[i].get("rejected"),
                        "tod_open": s._tod_open(i), "tod_charge": (s.meta[i].get("tod") or {}).get("charge")}
                       for i, o in s.orders.items()],
            "flows": s.flows, "rules": {"per_txn": s.rules.per_txn_cap, "per_instrument": s.rules.per_instrument_cap,
                                        "sla_min": s.rules.settlement_sla_min},
            "fee": s.flat_fee_inr, "agents_enabled": W.rt.enabled, "mode": s.credit_mode}


@app.post("/api/orders/{oid}/link")
def link(oid: str):
    try:
        return {"link": W.svc.request_payment(oid)}
    except Exception as e:
        err(e)


@app.post("/api/orders/{oid}/psp", dependencies=[Depends(demo_only)])
def psp(oid: str, p: Psp):
    """DEMO ONLY: plays the PSP, signing a callback for the current attempt and the amount due."""
    try:
        o = W.svc._order(oid)
        attempt, ts = W.svc.meta[oid]["attempt"], int(W.t)
        amt = o.total_due
        return {"state": W.svc.psp_webhook(oid, attempt, p.status, amt, ts,
                                           psp_sign(oid, attempt, p.status, amt, ts))}
    except Exception as e:
        err(e)


@app.post("/api/orders/{oid}/offer")
def offer(oid: str):
    try:
        return W.svc.offer_credit(oid)
    except Exception as e:
        err(e)


@app.post("/api/orders/{oid}/otp")
def otp(oid: str):
    try:
        code = W.svc.send_otp(oid)               # goes to the order's own mobile
        return {"sent": True, "demo_code": code if os.environ.get("AIRPAY_DEMO", "1") == "1" else None}
    except Exception as e:
        err(e)


@app.post("/api/orders/{oid}/authorise")
def authorise(oid: str, a: Auth):
    try:
        return W.svc.authorise_credit(oid, a.box, a.otp, a.kfs_hash)
    except Exception as e:
        err(e)


@app.post("/api/orders/{oid}/repay")
def repay(oid: str):
    try:
        return W.svc.repay_credit(oid)
    except Exception as e:
        err(e)


@app.get("/api/audit")
def audit():
    try:
        return run_audit_agent(W.svc, W.rt)
    except Exception as e:
        err(e)


@app.post("/api/agents/kill", dependencies=[Depends(demo_only)])
def kill():
    W.rt.kill()
    return {"agents_enabled": False}


@app.get("/api/rules")
def rules():
    return W.svc.rules.raw


@app.get("/")
def index():
    return FileResponse(WEB / "index.html")
