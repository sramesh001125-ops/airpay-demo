"""Simulators for the outside world: PSP (airline's payment provider), lender, OTP/SMS.
Replace with real integrations later; the service only talks to these interfaces."""
from __future__ import annotations

import hashlib
import hmac
import secrets
import time
from dataclasses import dataclass
from urllib.parse import urlencode

from .fees import CreditQuote

PSP_SECRET = b"demo-psp-shared-secret"   # demo only; real secret comes from a secret manager, never client-facing code
AIRLINE_VPA = "airline@psp"
BANK_SECRET = b"demo-bank-shared-secret"   # demo only; real: the bank's own signing key / mTLS, held in a secret manager


def bank_sign(order_id: str, event: str, ref: str, charge: int, ts: int, secret: bytes = BANK_SECRET) -> str:
    """The bank signs its own overdraft events: order, event, bank reference, charge and time."""
    return hmac.new(secret, f"{order_id}|{event}|{ref}|{charge}|{ts}".encode(), hashlib.sha256).hexdigest()


def bank_verify(order_id, event, ref, charge, ts, sig, secret: bytes = BANK_SECRET) -> bool:
    try:
        return hmac.compare_digest(bank_sign(order_id, event, ref, charge, ts, secret), sig)
    except (TypeError, ValueError):
        return False


def _msg(order_id: str, attempt: int, status: str, amount: int, ts: int) -> bytes:
    return f"{order_id}|{attempt}|{status}|{amount}|{ts}".encode()


def psp_sign(order_id: str, attempt: int, status: str, amount: int, ts: int, secret: bytes = PSP_SECRET) -> str:
    """The PSP signs order, attempt, status, PAID AMOUNT and time, so a callback cannot be replayed onto
    another attempt or used to report a smaller payment as a full one."""
    return hmac.new(secret, _msg(order_id, attempt, status, amount, ts), hashlib.sha256).hexdigest()


def psp_verify(order_id, attempt, status, amount, ts, sig, secret: bytes = PSP_SECRET) -> bool:
    try:
        return hmac.compare_digest(psp_sign(order_id, attempt, status, amount, ts, secret), sig)
    except (TypeError, ValueError):
        return False


class PSPSim:
    """Creates a UPI payment link; the merchant is the airline, so funds go passenger -> airline."""

    def create_link(self, order_id: str, attempt: int, amount_inr: int) -> str:
        # urlencode: no field can inject extra parameters (payee/amount) into the link
        return "upi://pay?" + urlencode({"pa": AIRLINE_VPA, "am": f"{amount_inr:.2f}", "tr": order_id,
                                         "tn": f"attempt {attempt}", "cu": "INR"})


@dataclass
class Loan:
    loan_id: str
    order_id: str
    lender: str
    principal_inr: float
    quote: CreditQuote
    booked_at: float
    repaid: bool = False


class LenderSim:
    """A willing lender (bank / SFB / NBFC). Books the loan in ITS books and pays the airline."""

    def __init__(self, name: str = "DemoBank", tenor_days: int = 5, charges_inr: float = 15.0):
        self.name, self.tenor_days, self.charges_inr = name, tenor_days, charges_inr
        # Passenger-facing wording must be supplied by the lender. This is a DEMO PLACEHOLDER, not approved text.
        self.disclosure_text = "[DEMO PLACEHOLDER - the lender supplies the approved wording, including any credit-reporting language.]"
        self.loans: dict[str, Loan] = {}
        self.payouts: list[dict] = []

    def quote(self, amount_inr: int) -> CreditQuote:
        return CreditQuote(amount_inr, self.charges_inr, self.tenor_days)

    def book(self, order_id: str, amount_inr: int, now: float) -> Loan:
        if any(l.order_id == order_id for l in self.loans.values()):
            raise ValueError("loan already booked for this order")
        ln = Loan(f"LN-{secrets.token_hex(4)}", order_id, self.name, amount_inr,
                  self.quote(amount_inr), now)
        self.loans[ln.loan_id] = ln
        return ln

    def pay_airline(self, loan: Loan, now: float) -> dict:
        if any(p["loan_id"] == loan.loan_id for p in self.payouts):
            raise ValueError("payout already made")
        p = {"loan_id": loan.loan_id, "order_id": loan.order_id, "amount_inr": loan.principal_inr,
             "from": self.name, "to": "airline", "at": now}
        self.payouts.append(p)
        return p

    def mark_repaid(self, loan_id: str) -> None:
        self.loans[loan_id].repaid = True


class OTPSim:
    """One-time code bound to an opaque key (the service uses order id + the order's own mobile).
    Single use, 3 wrong tries then dead, expires. Values are config to confirm with the lender/SMS gateway."""
    MAX_TRIES = 3
    TTL_S = 300

    def __init__(self, clock=None):
        self._clock = clock or time.time
        self._codes: dict[str, dict] = {}

    def send(self, key: str) -> str:
        code = f"{secrets.randbelow(10**6):06d}"
        self._codes[key] = {"code": code, "tries": 0, "at": self._clock()}
        return code   # returned only so the demo/tests can read it; a real SMS gateway would not

    def check(self, key: str, code: str) -> bool:
        rec = self._codes.get(key)
        if not rec or not isinstance(code, str):
            return False
        if self._clock() - rec["at"] > self.TTL_S or rec["tries"] >= self.MAX_TRIES:
            del self._codes[key]
            return False
        if hmac.compare_digest(rec["code"], code):
            del self._codes[key]   # one-time use
            return True
        rec["tries"] += 1
        if rec["tries"] >= self.MAX_TRIES:
            del self._codes[key]
        return False
