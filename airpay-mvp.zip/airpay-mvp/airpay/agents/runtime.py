"""Agent runtime: read-only snapshots in, advice out. Kill switch, full logging, no write access."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from ..service import Service


class AgentsDisabled(Exception):
    pass


def snapshot(svc: Service) -> dict:
    """Sanitised read-only copy. No mobile numbers, no keys, no OTPs, no object references."""
    return {
        "rules": {"per_txn_cap": svc.rules.per_txn_cap, "per_instrument_cap": svc.rules.per_instrument_cap,
                  "sla_min": svc.rules.settlement_sla_min},
        "orders": [{"id": oid, "flight": o.flight, "amount": o.amount_inr, "state": o.state.value,
                    "path": [h[1] for h in o.history],
                    "has_valid_consent": bool(o.consent and o.consent.valid())}
                   for oid, o in svc.orders.items()],
        "flows": [dict(f) for f in svc.flows],
        "now": svc.clock(),
    }


@dataclass
class Runtime:
    llm: object
    enabled: bool = True                      # kill switch
    log: list[dict] = field(default_factory=list)
    proposals: list[dict] = field(default_factory=list)   # rule-change proposals: human approval only

    def kill(self) -> None:
        self.enabled = False

    def run(self, agent: str, system: str, user: str) -> str:
        if not self.enabled:
            raise AgentsDisabled("agents are switched off")
        t = time.time()
        try:
            out = self.llm.complete(system, user)
            status = "ok"
        except Exception as e:
            out, status = f"[{agent} unavailable: {type(e).__name__}]", "error"
        self.log.append({"agent": agent, "status": status, "at": t,
                         "input_chars": len(user), "output_chars": len(out)})
        return out

    def propose_rule_change(self, agent: str, rule_id: str, change: str, evidence: str) -> dict:
        p = {"agent": agent, "rule_id": rule_id, "change": change, "evidence": evidence,
             "status": "PENDING_HUMAN_APPROVAL"}
        self.proposals.append(p)
        return p
