"""Provider-neutral LLM interface. Gemini (Google AI Studio key) is the first provider.
The key is read from the GEMINI_API_KEY environment variable and is never stored in code or logs."""
from __future__ import annotations

import os
from typing import Protocol

import requests


class LLM(Protocol):
    def complete(self, system: str, user: str) -> str: ...


class LLMUnavailable(Exception):
    pass


class GeminiLLM:
    URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

    def __init__(self, model: str | None = None, timeout: int = 30):
        # Model name is configuration, not code: confirm the current model name in AI Studio.
        self.model = model or os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
        self.timeout = timeout

    def complete(self, system: str, user: str) -> str:
        key = os.environ.get("GEMINI_API_KEY")
        if not key:
            raise LLMUnavailable("GEMINI_API_KEY not set")
        body = {"systemInstruction": {"parts": [{"text": system}]},
                "contents": [{"role": "user", "parts": [{"text": user}]}],
                "generationConfig": {"temperature": 0.2}}
        try:
            r = requests.post(self.URL.format(model=self.model), json=body,
                              headers={"x-goog-api-key": key}, timeout=self.timeout)
            r.raise_for_status()
            return r.json()["candidates"][0]["content"]["parts"][0]["text"]
        except Exception as e:   # never leak the key: report only the exception type
            raise LLMUnavailable(f"gemini call failed: {type(e).__name__}") from None


class FakeLLM:
    """Deterministic stand-in for tests and offline demos."""

    def __init__(self, reply: str = "FAKE: no model call made."):
        self.reply, self.calls = reply, []

    def complete(self, system: str, user: str) -> str:
        self.calls.append((system, user))
        return self.reply
