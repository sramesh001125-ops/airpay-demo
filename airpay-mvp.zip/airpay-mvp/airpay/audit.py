"""Deterministic auditor. Re-derives compliance from raw records; trusts nothing the service says
about itself. Read-only. Its findings are what the audit AGENT explains (agents/audit_agent.py).

KNOWN LIMIT: it audits records the same process wrote. A production audit must also reconcile against external
PSP and bank statements and an externally anchored ledger head (see docs/issues_log.md)."""
from __future__ import annotations

from dataclasses import dataclass, asdict
from urllib.parse import parse_qs, urlparse

from .crypto import verify_chain
from .fees import service_fee_split
from .orders import S
from .sims import AIRLINE_VPA
from .service import EXPOSED, ID_RE, MOBILE_RE, Service

AIRLINE_INFLOW = ("PSP_PAYMENT", "LOAN_DISBURSAL")


@dataclass
class Finding:
    check: str
    severity: str      # CRITICAL | HIGH | MEDIUM | INFO
    detail: str
    order: str = ""


def run_audit(svc: Service) -> list[Finding]:
    f: list[Finding] = []
    r = svc.rules
    now = svc.clock()

    def add(check, sev, detail, order=""):
        f.append(Finding(check, sev, detail, order))

    # A1 ledger integrity (self-consistency only; external anchoring is an open item)
    ok, why = verify_chain(svc.ledger.entries, svc.signer.public_b64)
    if not ok:
        add("A1_LEDGER_CHAIN", "CRITICAL", why)
    ledger_refs: dict[str, int] = {}
    for e in svc.ledger.entries:
        oid = e["payload"].get("order")
        if oid:
            ledger_refs[oid] = ledger_refs.get(oid, 0) + 1

    # fee sanity (A8)
    fee = svc.flat_fee_inr
    if type(fee) is not int or not (r.fee_low <= fee <= r.fee_high):
        add("A8_FEE_RANGE", "HIGH", f"fee {fee!r} outside Rs {r.fee_low}-{r.fee_high} or not whole rupees")

    exposure: dict[str, int] = {}
    for oid, o in svc.orders.items():
        m = svc.meta[oid]
        rejected = "rejected" in m
        path = [h[1] for h in o.history]
        # A2 amount sanity and per-transaction cap (every order, rejected or not)
        if not (type(o.amount_inr) is int and o.amount_inr > 0):
            add("A2_AMOUNT_TYPE", "CRITICAL", f"amount {o.amount_inr!r} is not a positive whole rupee amount", oid)
            continue
        if o.amount_inr > r.per_txn_cap and not rejected:
            add("A2_TXN_CAP", "CRITICAL", f"Rs {o.amount_inr} > cap {r.per_txn_cap}", oid)
        if type(o.fee_inr) is int and o.fee_inr > o.amount_inr * r.fee_max_pct / 100:
            add("A8_FEE_SHARE_OF_AMOUNT", "HIGH", f"fee Rs {o.fee_inr} > {r.fee_max_pct}% of Rs {o.amount_inr}", oid)
        # A12 id namespace
        mt = ID_RE.match(oid)
        if not mt or mt.group(2) != m["device"]:
            add("A12_ID_NAMESPACE", "HIGH", "order id not in its device's namespace", oid)
        if not MOBILE_RE.match(o.mobile or ""):
            add("A2_MOBILE", "HIGH", "order has no valid passenger mobile", oid)
        if o.state in EXPOSED or svc._tod_open(oid):
            exposure[o.mobile] = exposure.get(o.mobile, 0) + o.amount_inr
        # A11 every state change is in the ledger
        if ledger_refs.get(oid, 0) < len(o.history):
            add("A11_LEDGER_GAP", "HIGH", "state changes without matching ledger entries", oid)
        # A4 credit: consent, sequence, lender booking
        loans = [l for l in svc.lender.loans.values() if l.order_id == oid]
        payouts = [p for p in svc.lender.payouts if p["order_id"] == oid]
        if S.CREDIT_AUTHORISED.value in path:
            c = o.consent
            if not (c and c.valid()):
                add("A4_CONSENT", "CRITICAL", "credit without valid consent", oid)
            elif c.mobile != o.mobile:
                add("A4_CONSENT_MOBILE", "CRITICAL", "consent mobile differs from the order's passenger", oid)
            elif c.kfs_hash != m.get("kfs_hash"):
                add("A4_KFS_HASH", "CRITICAL", "consent does not match the key facts offered", oid)
            try:
                i_fail, i_off, i_auth = (path.index(x) for x in
                                         (S.PAYMENT_FAILED.value, S.CREDIT_OFFERED.value, S.CREDIT_AUTHORISED.value))
                if not (i_fail < i_off < i_auth):
                    add("A4_SEQUENCE", "CRITICAL", "credit steps out of order", oid)
            except ValueError:
                add("A4_NO_FAILED_PAYMENT", "CRITICAL", "credit without failed payment and offer", oid)
            if len(loans) != 1:
                add("A4_LOAN_COUNT", "CRITICAL", f"{len(loans)} loans in lender books for one credit order", oid)
            elif loans[0].principal_inr != o.total_due:
                add("A4_AMOUNT_MISMATCH", "HIGH", "loan principal != amount due", oid)
            if len(payouts) != 1 or (payouts and payouts[0]["amount_inr"] != o.total_due):
                add("A4_PAYOUT", "CRITICAL", f"lender payouts to airline: {len(payouts)}", oid)
        elif loans or payouts:
            add("A4_ORPHAN_LOAN", "CRITICAL", "loan or payout exists for an order that never took credit", oid)

        # A5/A6/A9 money: airline paid exactly once, exactly the amount due; RaMYOS only its fee share
        flows = [x for x in svc.flows if x["order"] == oid]
        inflow = sum(x["amount"] for x in flows if x["to"] == "airline" and x["kind"] in AIRLINE_INFLOW)
        settled = any(p in (S.PAID_VERIFIED.value, S.CREDIT_AUTHORISED.value) for p in path)
        expected = o.total_due if settled else 0
        if inflow != expected:
            add("A6_AIRLINE_AMOUNT", "CRITICAL", f"airline received Rs {inflow}, expected Rs {expected}", oid)
        shares = [x for x in flows if x["kind"] == "FEE_SHARE"]
        want = service_fee_split(o.fee_inr, svc.airline_share_pct)["ramyos_inr"] if settled else None
        if (settled and (len(shares) != 1 or shares[0]["amount"] != want)) or (not settled and shares):
            add("A9_FEE_SPLIT", "HIGH", f"fee share flows {[x['amount'] for x in shares]}, expected {want}", oid)
        if settled and oid not in svc.settlements:
            add("A6_UNSETTLED", "HIGH", "airline paid but no settlement time recorded", oid)
        t0, t1 = m.get("first_requested_at"), svc.settlements.get(oid)
        if t0 is not None and t1 is not None and (t1 - t0) / 60 > r.settlement_sla_min:
            add("A6_SLA", "HIGH", f"airline made whole {(t1 - t0) / 60:.0f} min after first link > {r.settlement_sla_min}", oid)
        # A7 stuck orders
        if o.state in (S.PAYMENT_REQUESTED, S.PAYMENT_FAILED, S.CREDIT_OFFERED) and t0 is not None:
            age = (now - t0) / 60
            if age > r.settlement_sla_min:
                add("A7_STUCK", "MEDIUM", f"{o.state.value} for {age:.0f} min, airline not yet whole", oid)
        # A15 link integrity
        if m.get("link"):
            q = parse_qs(urlparse(m["link"]).query)
            single = {k: v for k, v in q.items() if len(v) == 1}
            if (len(single) != len(q) or single.get("pa") != [AIRLINE_VPA] or single.get("tr") != [oid]
                    or single.get("am") != [f"{o.total_due:.2f}"]):
                add("A15_LINK", "CRITICAL", "payment link does not match order (payee/amount/ref)", oid)
        if any(x["kind"] == "REFUND_DUE" for x in flows):
            add("A13_REFUND_DUE", "HIGH", "passenger paid more than once; refund owed and no refund flow yet", oid)

    # A3 passenger-instrument exposure
    for mob, amt in exposure.items():
        if amt > r.per_instrument_cap:
            add("A3_INSTRUMENT_CAP", "CRITICAL", f"passenger ...{str(mob)[-4:]}: exposure Rs {amt} > {r.per_instrument_cap}")
    # A5 flows to RaMYOS and orphan flows / loans
    for x in svc.flows:
        if x["to"] == "ramyos" and x["kind"] != "FEE_SHARE":
            add("A5_FUNDS_HELD", "CRITICAL", f"{x['kind']} reached RaMYOS", x["order"])
        if x["order"] not in svc.orders:
            add("A5_ORPHAN_FLOW", "HIGH", f"{x['kind']} for unknown order", str(x["order"])[:40])
    for ln in svc.lender.loans.values():
        if ln.order_id not in svc.orders:
            add("A4_ORPHAN_LOAN", "CRITICAL", "loan for unknown order", ln.order_id)
        elif not ln.repaid:
            age = (now - ln.booked_at) / 86400
            if age > r.npa_days:
                add("A14_LOAN_NPA", "CRITICAL", f"loan {ln.loan_id} unrepaid {age:.0f} days: lender must classify as NPA (not a write-off)", ln.order_id)
            elif age > ln.quote.days:
                add("A14_LOAN_OVERDUE", "HIGH", f"loan {ln.loan_id} unrepaid past {ln.quote.days}-day due date", ln.order_id)
    # A16 temporary overdraft discipline: tenor ceiling, no new order and no second credit while one is open
    tods = []
    for oid2, o2 in svc.orders.items():
        m2 = svc.meta[oid2]
        if m2.get("loan_seq") is not None:
            tods.append((o2.mobile, m2["loan_seq"], m2.get("repaid_seq"), oid2))
        if m2.get("tod"):
            tods.append((o2.mobile, m2["tod"]["opened_seq"], m2["tod"]["cleared_seq"], oid2))
    for ln in svc.lender.loans.values():
        if ln.quote.days > r.tod_due_days:
            add("A16_TENOR_OVER_MAX", "HIGH", f"loan {ln.loan_id} tenor {ln.quote.days} days > maximum {r.tod_due_days}", ln.order_id)
    if r.block_while_tod:
        for mob, lseq, rseq, toid in tods:
            for oid3, o3 in svc.orders.items():
                m3 = svc.meta[oid3]
                if o3.mobile == mob and oid3 != toid and "rejected" not in m3:
                    iseq = m3.get("ingest_seq", -1)
                    if iseq > lseq and (rseq is None or iseq < rseq):
                        add("A16_ORDER_WHILE_TOD", "CRITICAL", "order accepted while the passenger had an open temporary overdraft", oid3)
            for mob2, lseq2, rseq2, toid2 in tods:
                if toid2 != toid and mob2 == mob and lseq2 > lseq and (rseq is None or lseq2 < rseq):
                    add("A16_SECOND_TOD", "CRITICAL", "second credit booked while the first was still open", toid2)
    # A17 credit-mode discipline and Mode A overdraft records
    for oid4, o4 in svc.orders.items():
        m4 = svc.meta[oid4]
        path4 = [h[1] for h in o4.history]
        t = m4.get("tod")
        if svc.credit_mode == "A_SB_OVERDRAFT" and (S.CREDIT_OFFERED.value in path4 or S.CREDIT_AUTHORISED.value in path4):
            add("A17_MODE_VIOLATION", "CRITICAL", "AirPay offered or arranged credit while in Mode A (bank decides)", oid4)
        if svc.credit_mode == "B_SEPARATE_LOAN" and t:
            add("A17_MODE_VIOLATION", "CRITICAL", "bank overdraft recorded while in Mode B", oid4)
        if t:
            if not t.get("ref"):
                add("A17_TOD_NO_REF", "CRITICAL", "overdraft recorded without a bank reference", oid4)
            if S.PAID_VERIFIED.value not in path4:
                add("A17_TOD_STATE", "HIGH", "overdraft recorded on an order the bank did not pay", oid4)
            if t["cleared_seq"] is None:
                age = (now - t["opened_at"]) / 86400
                if age > r.npa_days:
                    add("A14_TOD_NPA", "CRITICAL", f"overdraft open {age:.0f} days: bank must classify as NPA (not a write-off)", oid4)
                elif age > r.tod_due_days:
                    add("A14_TOD_OVERDUE", "HIGH", f"overdraft open {age:.0f} days > maximum {r.tod_due_days}", oid4)
            else:
                reps = [x for x in svc.flows if x["order"] == oid4 and x["kind"] == "LOAN_REPAYMENT"]
                if len(reps) != 1 or reps[0]["amount"] != o4.total_due + t["charge"]:
                    add("A17_TOD_REPAY_FLOW", "HIGH", "cleared overdraft has no single matching auto-debit flow", oid4)
    # A10 open regulatory items always reported
    open_rules = [k for k, v in r.raw["limits"].items() if v.get("status") != "VERIFIED"]
    add("A10_OPEN_ITEMS", "INFO", "UNVERIFIED/PARTIAL/ASSUMPTION rules remain: " + ", ".join(open_rules))
    return f


def summarise(findings: list[Finding]) -> dict:
    sev: dict[str, int] = {}
    for x in findings:
        sev[x.severity] = sev.get(x.severity, 0) + 1
    return {"counts": sev, "pass": not any(x.severity in ("CRITICAL", "HIGH") for x in findings),
            "findings": [asdict(x) for x in findings]}
