"""Rules engine: loads config/rules.yaml and decides whether an order may be taken offline.

Deterministic. No agent can change a decision here; agents may only propose edits to the YAML,
which a human approves.
"""
from __future__ import annotations

import pathlib
from dataclasses import dataclass, field

import yaml

DEFAULT_PATH = pathlib.Path(__file__).resolve().parent.parent / "config" / "rules.yaml"


@dataclass
class Decision:
    allowed: bool
    reasons: list[str] = field(default_factory=list)
    rule_ids: list[str] = field(default_factory=list)


def is_rupees(x) -> bool:
    """A positive whole number of rupees. Rejects bool, float (incl. NaN/inf), str, None."""
    return type(x) is int and x > 0


class Rules:
    def __init__(self, path: pathlib.Path | str = DEFAULT_PATH):
        self.path = pathlib.Path(path)
        self.raw = yaml.safe_load(self.path.read_text())
        lim, fees = self.raw["limits"], self.raw["fees"]
        self.per_txn_cap = int(lim["per_transaction_cap_inr"]["value"])
        self.per_instrument_cap = int(lim["per_instrument_cap_inr"]["value"])
        self.over_cap_policy = lim["over_cap_item_policy"]["value"]
        self.settlement_sla_min = int(self.raw["pilot_assumptions"]["settlement_sla_minutes"])
        self.tod_due_days = int(self.raw['credit']['tod_due_days']['value'])
        self.npa_days = int(self.raw['credit']['npa_days']['value'])
        self.lender_terms_confirmed = bool(self.raw['credit']['lender_terms_confirmed']['value'])
        self.credit_mode = str(self.raw['credit']['credit_mode']['value'])
        if self.credit_mode not in self.raw['credit']['credit_mode']['options']:
            raise ValueError('unknown credit mode')
        self.block_while_tod = bool(self.raw['credit']['block_new_orders_while_tod_outstanding']['value'])
        self.default_fee = int(fees["flat_fee_inr"]["value"])
        self.fee_low = int(fees["flat_fee_range_inr"]["low"])
        self.fee_high = int(fees["flat_fee_range_inr"]["high"])
        self.fee_max_pct = float(fees["fee_max_pct_of_amount"]["value"])
        self.airline_share_pct = float(fees["airline_share_pct"])

    def check_order(self, item_prices_inr: list, open_exposure_inr: int) -> Decision:
        """Each priced item is one transaction. Refused if any item is not a whole positive rupee amount,
        exceeds the per-transaction cap, or if the passenger-instrument exposure would pass its cap."""
        if not isinstance(item_prices_inr, list) or not item_prices_inr \
                or not all(is_rupees(p) for p in item_prices_inr):
            return Decision(False, ["amount must be a positive whole number of rupees"], ["TYPE"])
        if type(open_exposure_inr) is not int or open_exposure_inr < 0:
            return Decision(False, ["invalid open exposure figure"], ["TYPE"])
        reasons: list[str] = []
        ids: list[str] = []
        for p in item_prices_inr:
            if p > self.per_txn_cap:
                reasons.append(f"item Rs {p} exceeds per-transaction cap Rs {self.per_txn_cap}")
                ids.append("LIM-01" if self.over_cap_policy != "NOT_ELIGIBLE_OFFLINE" else "LIM-03")
        total = sum(item_prices_inr)
        if open_exposure_inr + total > self.per_instrument_cap:
            reasons.append(f"passenger exposure Rs {open_exposure_inr} + new Rs {total} exceeds "
                           f"instrument cap Rs {self.per_instrument_cap}")
            ids.append("LIM-02")
        return Decision(not reasons, reasons, sorted(set(ids)))
