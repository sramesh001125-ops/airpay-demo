"""Deterministic core service. Decides money, consent and credit. Agents never call write methods."""
from __future__ import annotations

import hashlib
import re
import secrets
import time
from typing import Callable

from .crypto import CrewLog, Signer, canon, make_token, read_token, verify_chain
from .fees import service_fee_split
from .orders import Consent, Order, S, TransitionError
from .rules import Rules, is_rupees
from .sims import AIRLINE_VPA, LenderSim, OTPSim, PSPSim, bank_verify, psp_verify

UNPAID = {S.PURCHASE_RECORDED, S.PAYMENT_REQUESTED, S.PAYMENT_FAILED, S.CREDIT_OFFERED}
# what counts against a passenger's instrument cap: unpaid, credit not yet repaid, or disputed
EXPOSED = UNPAID | {S.CREDIT_AUTHORISED, S.DISPUTED}

FLIGHT_RE = re.compile(r"^[A-Z0-9]{2}-\d{1,4}$")
DEVICE_RE = re.compile(r"^[A-Z0-9]{1,12}$")
MOBILE_RE = re.compile(r"^[6-9]\d{9}$")
ID_RE = re.compile(r"^([A-Z0-9]{2}-\d{1,4})-([A-Z0-9]{1,12})-(\d{4})$")   # <flight>-<device>-<nnnn>

MODE_A, MODE_B = "A_SB_OVERDRAFT", "B_SEPARATE_LOAN"
REF_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
MAX_TOD_CHARGE_INR = 100          # sanity ceiling on a bank-reported overdraft charge (config candidate)
WEBHOOK_WINDOW_S = 300
MAX_OTP_SENDS = 3


class ServiceError(Exception):
    pass


class Service:
    def __init__(self, rules: Rules | None = None, lender: LenderSim | None = None,
                 clock: Callable[[], float] = time.time, flat_fee_inr: int | None = None,
                 lender_terms_confirmed: bool | None = None, credit_mode: str | None = None):
        self.rules = rules or Rules()
        self.credit_mode = credit_mode or self.rules.credit_mode
        if self.credit_mode not in (MODE_A, MODE_B):
            raise ValueError("unknown credit mode")
        self.lender = lender or LenderSim(tenor_days=self.rules.tod_due_days)
        if self.lender.tenor_days > self.rules.tod_due_days:
            raise ValueError("lender tenor is longer than the maximum temporary overdraft period")
        self.clock = clock
        self.lender_terms_confirmed = (self.rules.lender_terms_confirmed if lender_terms_confirmed is None
                                       else lender_terms_confirmed)
        self.psp, self.otp = PSPSim(), OTPSim(clock)
        self.flat_fee_inr = self.rules.default_fee if flat_fee_inr is None else flat_fee_inr
        self.airline_share_pct = self.rules.airline_share_pct
        self.signer = Signer()                        # server key: signs ledger + QR tokens
        self.ledger = CrewLog("server", self.signer)  # hash-chained record of every decision
        self.orders: dict[str, Order] = {}
        self.meta: dict[str, dict] = {}               # per-order extras (device, link, attempt, kfs hash, loan)
        self.devices: dict[str, dict] = {}            # device -> {pub, last_seq, hashes}
        self.flows: list[dict] = []                   # every movement of money, for audit
        self.settlements: dict[str, float] = {}       # order_id -> time airline was made whole
        self.seen_events: set = set()                 # webhook idempotency

    # ---- helpers
    def _log(self, kind: str, **kw) -> None:
        self.ledger.append({"kind": kind, **kw}, ts=self.clock())

    def _tod_open(self, oid: str) -> bool:
        t = self.meta[oid].get("tod")
        return bool(t) and t["cleared_seq"] is None

    def _exposure(self, mobile: str) -> int:
        return sum(o.amount_inr for oid, o in self.orders.items()
                   if o.mobile == mobile and (o.state in EXPOSED or self._tod_open(oid)))

    def _has_open_tod(self, mobile: str) -> bool:
        return any(o.mobile == mobile and (o.state == S.CREDIT_AUTHORISED or self._tod_open(oid))
                   for oid, o in self.orders.items())

    def blocked_mobiles(self) -> list[str]:
        """Passengers with an open temporary overdraft. Synced to crew devices BEFORE the flight so a sale is
        refused on board, not after the goods are served. (Production: send salted hashes, not numbers.)"""
        return sorted({o.mobile for oid, o in self.orders.items()
                       if o.state == S.CREDIT_AUTHORISED or self._tod_open(oid)})

    def _order(self, oid) -> Order:
        if not isinstance(oid, str) or oid not in self.orders:
            raise ServiceError("unknown order")
        return self.orders[oid]

    def register_device(self, device: str, public_b64: str) -> None:
        if not isinstance(device, str) or not DEVICE_RE.match(device):
            raise ServiceError("invalid device id")
        if device in self.devices:
            raise ServiceError("device already registered (keys are immutable; rotation needs dual control)")
        self.devices[device] = {"pub": public_b64, "last_seq": -1, "hashes": {}}
        self._log("DEVICE_REGISTERED", device=device)

    # ---- 1. offline crew log arrives after landing
    def sync_crew_log(self, device: str, entries: list) -> dict:
        d = self.devices.get(device)
        if not d:
            raise ServiceError("unknown device")
        if not isinstance(entries, list):
            raise ServiceError("malformed log")
        ok, why = verify_chain(entries, d["pub"])
        if ok and any(e["device"] != device for e in entries):
            ok, why = False, "entry signed for another device"
        if ok:
            for e in entries:   # a log must extend what we already hold; a different tail is a fork
                held = d["hashes"].get(e["seq"])
                if held is not None and held != e["hash"]:
                    ok, why = False, f"entry {e['seq']}: fork detected (history differs from what was synced before)"
                    break
        if not ok:
            self._log("SYNC_REJECTED", device=device, reason=why)
            raise ServiceError(f"crew log failed verification: {why}")
        res: dict = {"accepted": [], "rejected": [], "duplicates": [], "invalid": []}
        for e in entries:
            d["hashes"].setdefault(e["seq"], e["hash"])
            if e["seq"] <= d["last_seq"]:
                continue                              # already processed (replay or prefix resend)
            d["last_seq"] = e["seq"]                  # advance first: one bad entry must never wedge the device
            try:
                self._ingest(device, e, res)
            except Exception as ex:                   # contain anything unexpected, record it, carry on
                res["invalid"].append(e["seq"])
                self._log("ENTRY_ERROR", device=device, seq=e["seq"], error=type(ex).__name__)
        return res

    def _validate_payload(self, device: str, p: dict) -> str:
        oid = p.get("order_id")
        m = ID_RE.match(oid) if isinstance(oid, str) else None
        if not m:
            return "order id format"
        if m.group(2) != device:
            return "order id does not belong to this device"
        if p.get("flight") != m.group(1) or not FLIGHT_RE.match(str(p.get("flight"))):
            return "flight does not match order id"
        if not is_rupees(p.get("amount_inr")):
            return "amount must be a positive whole number of rupees"
        if not (isinstance(p.get("mobile"), str) and MOBILE_RE.match(p["mobile"])):
            return "passenger mobile missing or invalid"
        return ""

    def _ingest(self, device: str, e: dict, res: dict) -> None:
        p = e["payload"]
        if not isinstance(p, dict) or p.get("type") != "order":
            return
        bad = self._validate_payload(device, p)
        if bad:
            res["invalid"].append(e["seq"])
            self._log("ENTRY_INVALID", device=device, seq=e["seq"], reason=bad)
            return
        oid, mobile = p["order_id"], p["mobile"]
        if oid in self.orders:
            res["duplicates"].append(oid)
            self._log("DUPLICATE_ID", device=device, order=oid)
            return
        dec = self.rules.check_order([p["amount_inr"]], self._exposure(mobile))
        reasons, rule_ids = list(dec.reasons), list(dec.rule_ids)
        if self.rules.block_while_tod and self._has_open_tod(mobile):
            reasons.append("passenger has an open temporary overdraft; it must be cleared first")
            rule_ids.append("CR-04")
        o = Order(oid, p["flight"], p["amount_inr"], fee_inr=self.flat_fee_inr, mobile=mobile)
        self.orders[oid] = o
        self.meta[oid] = {"device": device, "seq": e["seq"], "attempt": 0, "ingest_seq": len(self.ledger.entries)}
        if not reasons:
            res["accepted"].append(oid)
            self._log("ORDER_ACCEPTED", order=oid, device=device, amount=o.amount_inr)
        else:
            o.go(S.CANCELLED, "system")
            self.meta[oid]["rejected"] = reasons
            res["rejected"].append(oid)
            self._log("ORDER_RULE_REJECTED", order=oid, rules=sorted(set(rule_ids)), reasons=reasons)

    # ---- 2. post-landing payment link
    def request_payment(self, oid: str) -> str:
        o = self._order(oid)
        m = self.meta[oid]
        o.go(S.PAYMENT_REQUESTED, "system")
        m["attempt"] += 1
        now = self.clock()
        m["link"] = self.psp.create_link(oid, m["attempt"], o.total_due)
        m.setdefault("first_requested_at", now)
        m["requested_at"] = now
        self._log("PAYMENT_REQUESTED", order=oid, attempt=m["attempt"])
        return m["link"]

    def psp_webhook(self, oid: str, attempt: int, status: str, amount: int, ts: int, sig: str) -> str:
        if not isinstance(ts, int) or abs(self.clock() - ts) > WEBHOOK_WINDOW_S:
            self._log("WEBHOOK_STALE", order=str(oid)[:40])
            raise ServiceError("webhook outside the allowed time window")
        if not psp_verify(oid, attempt, status, amount, ts, sig):
            self._log("WEBHOOK_BAD_SIGNATURE", order=str(oid)[:40])
            raise ServiceError("bad webhook signature")
        o = self._order(oid)
        m = self.meta[oid]
        if not (isinstance(attempt, int) and 1 <= attempt <= m["attempt"]):
            raise ServiceError("unknown payment attempt")
        key = (oid, attempt, status, ts)
        if key in self.seen_events:
            return o.state.value                      # idempotent: same callback twice changes nothing
        self.seen_events.add(key)
        if status == "PAID":
            if amount != o.total_due:
                self._log("WEBHOOK_AMOUNT_MISMATCH", order=oid, paid=amount, due=o.total_due)
                raise ServiceError("paid amount does not match amount due")
            if o.state in (S.PAYMENT_REQUESTED, S.PAYMENT_FAILED, S.CREDIT_OFFERED):
                o.go(S.PAID_VERIFIED, "psp")          # includes a late success after a reported failure
                self._airline_made_whole(oid, "PSP_PAYMENT", "passenger")
            else:                                     # paid again after credit/paid/cancelled: money to give back
                self.flows.append({"order": oid, "kind": "REFUND_DUE", "from": "airline", "to": "passenger",
                                   "amount": amount})
                self._log("DUPLICATE_PAYMENT", order=oid, attempt=attempt)
        elif status == "FAILED":
            if o.state == S.PAYMENT_REQUESTED and attempt == m["attempt"]:
                o.go(S.PAYMENT_FAILED, "psp")
                m["failed_at"] = self.clock()
            else:                                     # a stale failure must not push a live order toward credit
                self._log("STALE_FAILED_IGNORED", order=oid, attempt=attempt)
        else:
            raise ServiceError("unknown status")
        self._log("WEBHOOK", order=oid, attempt=attempt, status=status)
        return o.state.value

    def _airline_made_whole(self, oid: str, kind: str, source: str) -> None:
        """The airline receives the full amount due (item + fee) exactly once; RaMYOS only ever gets its fee share."""
        o = self.orders[oid]
        sp = service_fee_split(o.fee_inr, self.airline_share_pct)
        self.flows.append({"order": oid, "kind": kind, "from": source, "to": "airline", "amount": o.total_due})
        self.flows.append({"order": oid, "kind": "FEE_SHARE", "from": "airline", "to": "ramyos",
                           "amount": sp["ramyos_inr"]})
        self.settlements[oid] = self.clock()

    # ---- 3. optional short credit: only after a failed payment, only with consent
    def offer_credit(self, oid: str) -> dict:
        o = self._order(oid)
        if self.credit_mode != MODE_B:
            raise ServiceError("Mode A: the bank decides at payment time; AirPay does not offer or arrange credit")
        if not self.lender_terms_confirmed:
            raise ServiceError("credit offer is switched off until the lender confirms its terms and wording (CR-05)")
        if self.rules.block_while_tod and self._has_open_tod(o.mobile):
            raise ServiceError("passenger already has an open temporary overdraft; no second credit until it is cleared")
        o.go(S.CREDIT_OFFERED, "system")
        q = self.lender.quote(o.total_due)
        kf = q.key_facts()
        h = hashlib.sha256(canon(kf)).hexdigest()
        m = self.meta[oid]
        m.update(kfs_hash=h, offered_at=self.clock(), otp_sends=0)
        self._log("CREDIT_OFFERED", order=oid, kfs=kf, kfs_hash=h)
        return {"lender": self.lender.name, "key_facts": kf, "kfs_hash": h,
                "note": self.lender.disclosure_text}      # passenger-facing wording comes ONLY from the lender

    def send_otp(self, oid: str) -> str:
        """OTP goes ONLY to the mobile recorded on the order, and is bound to this order."""
        o = self._order(oid)
        m = self.meta[oid]
        if o.state != S.CREDIT_OFFERED:
            raise ServiceError("no credit offer for this order")
        if m["otp_sends"] >= MAX_OTP_SENDS:
            raise ServiceError("too many OTP requests for this order")
        m["otp_sends"] += 1
        return self.otp.send(f"{oid}|{o.mobile}")

    def authorise_credit(self, oid: str, box_ticked: bool, otp: str, kfs_hash: str) -> dict:
        o = self._order(oid)
        m = self.meta[oid]
        if o.state != S.CREDIT_OFFERED:               # state is checked BEFORE the OTP is touched
            raise ServiceError("no live credit offer for this order")
        if box_ticked is not True:
            self._log("CREDIT_REFUSED", order=oid, reason="box not ticked")
            raise ServiceError("consent box not ticked")
        if kfs_hash != m["kfs_hash"]:
            self._log("CREDIT_REFUSED", order=oid, reason="key facts not acknowledged")
            raise ServiceError("key fact statement not acknowledged as offered")
        otp_ok = self.otp.check(f"{oid}|{o.mobile}", otp)
        consent = Consent(True, otp_ok, kfs_hash, m["kfs_hash"], o.mobile, self.clock())
        if not consent.valid():
            self._log("CREDIT_REFUSED", order=oid, reason="otp")
            raise ServiceError("OTP not valid")
        now = self.clock()
        try:
            ln = self.lender.book(oid, o.total_due, now)     # booked in the LENDER's books
            pay = self.lender.pay_airline(ln, now)            # lender -> airline, not via RaMYOS
        except Exception as ex:
            self._log("LENDER_ERROR", order=oid, error=type(ex).__name__)
            raise ServiceError("lender could not book the credit")
        o.go(S.CREDIT_AUTHORISED, "passenger", consent)
        m["loan"] = ln.loan_id
        m["loan_seq"] = len(self.ledger.entries)
        self._airline_made_whole(oid, "LOAN_DISBURSAL", self.lender.name)
        self._log("CREDIT_AUTHORISED", order=oid, loan=ln.loan_id, mobile_tail=o.mobile[-4:], kfs_hash=kfs_hash)
        return {"loan_id": ln.loan_id, "airline_paid": pay["amount_inr"]}

    def repay_credit(self, oid: str, how: str = "AUTO_DEBIT") -> dict:
        """Clears the temporary overdraft. Normal path: the passenger adds money to the savings account and the
        lender AUTO-DEBITS the due (how="AUTO_DEBIT"). Money goes to the lender only, never the airline or RaMYOS.
        Frees the passenger's instrument cap and lifts the new-order block."""
        if how not in ("AUTO_DEBIT", "PASSENGER_PAYMENT"):
            raise ServiceError("unknown repayment method")
        o = self._order(oid)
        m = self.meta[oid]
        if o.state != S.CREDIT_AUTHORISED or not m.get("loan"):
            raise ServiceError("no outstanding credit on this order")
        ln = self.lender.loans[m["loan"]]
        self.lender.mark_repaid(ln.loan_id)
        m["repaid_seq"] = len(self.ledger.entries)
        o.go(S.PAID_VERIFIED, "lender")
        self.flows.append({"order": oid, "kind": "LOAN_REPAYMENT", "from": "passenger", "to": self.lender.name,
                           "amount": ln.quote.total_repayable_inr, "via": how})
        self._log("CREDIT_REPAID", order=oid, loan=ln.loan_id, how=how)
        return {"repaid": ln.quote.total_repayable_inr}

    # ---- Mode A: the bank's own temporary overdraft on the passenger's savings account.
    # The UPI payment itself succeeded (normal PAID webhook, airline paid by normal UPI settlement). The bank then
    # tells us, signed, that it honoured the payment on overdraft, and later that the due was auto-debited.
    def _bank_event_ok(self, oid, event, ref, charge, ts, sig) -> None:
        if self.credit_mode != MODE_A:
            raise ServiceError("bank overdraft events are only accepted in Mode A")
        if not isinstance(ts, int) or abs(self.clock() - ts) > WEBHOOK_WINDOW_S:
            self._log("BANK_EVENT_STALE", order=str(oid)[:40])
            raise ServiceError("bank event outside the allowed time window")
        if not (isinstance(ref, str) and REF_RE.match(ref)):
            raise ServiceError("invalid bank reference")
        if not bank_verify(oid, event, ref, charge, ts, sig):
            self._log("BANK_EVENT_BAD_SIGNATURE", order=str(oid)[:40])
            raise ServiceError("bad bank event signature")

    def bank_tod_opened(self, oid: str, ref: str, charge: int, ts: int, sig: str) -> str:
        self._bank_event_ok(oid, "TOD_OPENED", ref, charge, ts, sig)
        o = self._order(oid)
        m = self.meta[oid]
        if type(charge) is not int or not (0 <= charge <= MAX_TOD_CHARGE_INR):
            raise ServiceError("overdraft charge must be whole rupees within the allowed range")
        key = (oid, "TOD_OPENED", ref, ts)
        if key in self.seen_events:
            return "TOD_OPEN"
        if o.state != S.PAID_VERIFIED:
            raise ServiceError("an overdraft can only be recorded against an order the bank has paid")
        if m.get("tod"):
            raise ServiceError("an overdraft is already recorded for this order")
        self.seen_events.add(key)
        m["tod"] = {"ref": ref, "charge": charge, "opened_seq": len(self.ledger.entries),
                    "opened_at": self.clock(), "cleared_seq": None}
        self._log("TOD_OPENED", order=oid, ref=ref, charge=charge)
        return "TOD_OPEN"

    def bank_tod_cleared(self, oid: str, ref: str, ts: int, sig: str) -> str:
        """Passenger added money to the savings account; the bank auto-debited the due. Lifts the block."""
        self._bank_event_ok(oid, "TOD_CLEARED", ref, 0, ts, sig)
        o = self._order(oid)
        m = self.meta[oid]
        key = (oid, "TOD_CLEARED", ref, ts)
        if key in self.seen_events:
            return "TOD_CLEARED"
        t = m.get("tod")
        if not t or t["cleared_seq"] is not None or t["ref"] != ref:
            raise ServiceError("no matching open overdraft for this order")
        self.seen_events.add(key)
        t["cleared_seq"] = len(self.ledger.entries)
        t["cleared_at"] = self.clock()
        self.flows.append({"order": oid, "kind": "LOAN_REPAYMENT", "from": "passenger", "to": self.lender.name,
                           "amount": o.total_due + t["charge"], "via": "AUTO_DEBIT"})
        self._log("TOD_CLEARED", order=oid, ref=ref)
        return "TOD_CLEARED"

    # ---- QR token: lets the passenger's phone pull the pay link after landing
    def token_for(self, oid: str, ttl_s: int = 6 * 3600) -> str:
        o = self._order(oid)
        return make_token({"order": oid, "amt": o.total_due, "exp": self.clock() + ttl_s,
                           "jti": secrets.token_hex(6)}, self.signer)

    def redeem_token(self, token: str, oid: str) -> str:
        ok, payload = read_token(token, self.signer.public_b64, self.clock())
        if not ok:
            raise ServiceError(f"token refused: {payload}")
        o = self._order(oid)
        if payload.get("order") != oid or payload.get("amt") != o.total_due:
            raise ServiceError("token does not match this order")
        if o.state != S.PAYMENT_REQUESTED:
            raise ServiceError("order is not awaiting payment")
        return self.meta[oid]["link"]
