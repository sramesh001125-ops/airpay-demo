On the Lightsail instance (Ubuntu 24.04):
  sudo apt-get install -y unzip && unzip airpay-mvp.zip && cd airpay-mvp
  bash deploy/setup.sh 'YourDemoPassword' 3.107.175.94
In Lightsail > Networking, open port 443 (HTTPS) in the IPv4 firewall (80 is also needed for the certificate).
