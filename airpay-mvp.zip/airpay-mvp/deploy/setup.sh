#!/usr/bin/env bash
# RaMYOS AirPay demo: one-shot setup for a fresh Ubuntu 24.04 Lightsail instance.
# Usage:  bash deploy/setup.sh <demo-password> <public-ipv4>
# Result: https://<ip-with-dashes>.sslip.io  (HTTPS, password-protected, user "demo")
set -euo pipefail
PASS="${1:?usage: setup.sh <password> <public-ipv4>}"
IP="${2:?usage: setup.sh <password> <public-ipv4>}"
HOST="$(echo "$IP" | tr . -).sslip.io"
APP=/opt/airpay
sudo apt-get update -y
sudo apt-get install -y python3-venv unzip debian-keyring debian-archive-keyring apt-transport-https curl gpg
# Caddy: automatic HTTPS + password
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
sudo apt-get update -y && sudo apt-get install -y caddy
# App
sudo mkdir -p "$APP" && sudo cp -r . "$APP/" && sudo chown -R ubuntu:ubuntu "$APP"
python3 -m venv "$APP/venv"
"$APP/venv/bin/pip" install -q -r "$APP/requirements.txt"
(cd "$APP" && "$APP/venv/bin/python" -m pytest -q 2>&1 | tail -2 || true)
sudo tee /etc/systemd/system/airpay.service >/dev/null <<UNIT
[Unit]
Description=RaMYOS AirPay demo
After=network.target
[Service]
User=ubuntu
WorkingDirectory=$APP
Environment=AIRPAY_DEMO=1
# Optional: Environment=GEMINI_API_KEY=...
ExecStart=$APP/venv/bin/uvicorn airpay.api:app --host 127.0.0.1 --port 8000
Restart=always
[Install]
WantedBy=multi-user.target
UNIT
HASH="$(caddy hash-password --plaintext "$PASS")"
sudo tee /etc/caddy/Caddyfile >/dev/null <<CADDY
$HOST {
    basic_auth {
        demo $HASH
    }
    reverse_proxy 127.0.0.1:8000
}
CADDY
sudo systemctl daemon-reload
sudo systemctl enable --now airpay
sudo systemctl restart caddy
echo "Done. Open https://$HOST  (user: demo)"
